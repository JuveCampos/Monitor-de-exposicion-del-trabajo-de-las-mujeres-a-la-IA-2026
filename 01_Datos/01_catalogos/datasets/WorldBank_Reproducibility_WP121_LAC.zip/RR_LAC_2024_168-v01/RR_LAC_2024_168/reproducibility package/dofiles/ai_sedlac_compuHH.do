************************* AI EXPOSURE & COMPUTER/INTERNET AT HOME (SEDLAC)*************************

*** Countries with ISCO 4d information
local base_in_1   "$path\bases\sedlac\CHL\CHL_2022_CASEN_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_2   "$path\bases\sedlac\DOM\DOM_2021_ECNFT_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_3   "$path\bases\sedlac\ECU\ECU_2021_ENEMDU_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_4   "$path\bases\sedlac\HND\HND_2019_EPHPM_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_5   "$path\bases\sedlac\PAN\PAN_2018_EH_v01_M_v05_A_SEDLAC-03_all.dta"
local base_in_6   "$path\bases\sedlac\PER\PER_2021_ENAHO_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_7   "$path\bases\sedlac\SLV\SLV_2021_EHPM_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_8   "$path\bases\sedlac\URY\URY_2021_ECH-S2_v01_M_v01_A_SEDLAC-03_all.dta"


* Number of countries with ISCO 4d information
local t = 8


forvalue i = 1/`t'	{

use "`base_in_`i''", clear
di in ye "Base = `base_in_`i''"

replace pais=lower(pais)

* Chile 2022 (4d)
if `i'==1 {
local pais = "chl"

replace isco08_4d = "." if  isco08_4d == "0-66"
replace isco08_4d = "." if  isco08_4d == "0-88"
replace isco08_4d = "." if  isco08_4d == "0-99"

destring isco08_4d, replace 

* Calculos a 2 dígitos
replace isco08_2d="" if isco08_2d=="0-"
destring isco08_2d, replace
summ isco* 
}


* República Dominicana 2021 (4d)
if `i'==2 {
local pais = "dom"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Ecuador 2021 (4d)
if `i'==3 {
local pais = "ecu"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Honduras 2019 (4d)
if `i'==4 {
local pais = "hnd"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Panama 2018 (4d)
if `i'==5 {
local pais = "pan"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 

* Replace variable "sector"
replace sector = 2 if sector==3
}


* Peru 2021 (4d)
if `i'==6 {
local pais = "per"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* El Salvador 2021 (4d)
if `i'==7 {
local pais = "slv"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Uruguay 2021 (4d)
if `i'==8 {
local pais = "ury"

replace isco08_4d = "." if  isco08_4d == "0"
destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}




* Calculos para potential (AI)
sort isco08_4d
merge isco08_4d using "$path\bases\Processed\ILO_db.dta", force
ta _merge
keep if _merge==1 | _merge==3
drop _merge


* Genero variable computadora para todos los miembros del hogar
egen compu_hh = max(computadora), by(id)
gen ncompu_hh=1-compu_hh

* Genero variable internet_casa para todos los miembros del hogar
egen internet_hh = max(internet_casa), by(id)
gen ninternet_hh=1-internet_hh

* Genero variable internet_casa Y computadora
gen int_y_comp= compu_hh*internet_hh
gen nint_y_comp= 1-int_y_comp

* Genero variable internet_casa O computadora
gen int_o_comp= 1 if compu_hh==1 | internet_hh==1
replace int_o_comp= 0 if compu_hh==0 & internet_hh==0

summ compu_hh
local ncomp=r(N)
summ internet_hh
local nint=r(N)
if `ncomp'==0 | `nint'==0 {
capture drop int_o_comp
gen int_o_comp= .
}
gen nint_o_comp= 1-int_o_comp


ta potential, g(pot)
rename pot1 pot_augmen
rename pot2 pot_automa
rename pot3 pot_unknown
rename pot4 pot_missing


** Generate variables to estimate probabilities
* AI + Computadora en casa
/*
Pr(Augmentation=1, Computer at home=1)
Pr(Augmentation=1, Computer at home=0)
Pr(Automation=1, Computer at home=1)
Pr(Automation=1, Computer at home=0)
Pr(Big Unknown=1, Computer at home=1)
Pr(Big Unknown=1, Computer at home=0)
Pr(Missing=1, Computer at home=1)
Pr(Missing=1, Computer at home=0)
*/
gen augmen_compuHH=pot_augmen*compu_hh
gen augmen_ncompuHH=pot_augmen*ncompu_hh
gen automa_compuHH=pot_automa*compu_hh
gen automa_ncompuHH=pot_automa*ncompu_hh
gen unknown_compuHH=pot_unknown*compu_hh
gen unknown_ncompuHH=pot_unknown*ncompu_hh
gen missing_compuHH=pot_missing*compu_hh
gen missing_ncompuHH=pot_missing*ncompu_hh

* AI + Internet en casa
/*
Pr(Augmentation=1, Internet at home=1)
Pr(Augmentation=1, Internet at home=0)
Pr(Automation=1, Internet at home=1)
Pr(Automation=1, Internet at home=0)
Pr(Big Unknown=1, Internet at home=1)
Pr(Big Unknown=1, Internet at home=0)
Pr(Missing=1, Internet at home=1)
Pr(Missing=1, Internet at home=0)
*/
gen augmen_interHH=pot_augmen*internet_hh
gen augmen_ninterHH=pot_augmen*ninternet_hh
gen automa_interHH=pot_automa*internet_hh
gen automa_ninterHH=pot_automa*ninternet_hh
gen unknown_interHH=pot_unknown*internet_hh
gen unknown_ninterHH=pot_unknown*ninternet_hh
gen missing_interHH=pot_missing*internet_hh
gen missing_ninterHH=pot_missing*ninternet_hh

* AI + Internet en casa & Computadora en casa
/*
Pr(Augmentation=1, Internet & CPU at home=1)
Pr(Augmentation=1, Internet & CPU at home=0)
Pr(Automation=1, Internet & CPU at home=1)
Pr(Automation=1, Internet & CPU at home=0)
Pr(Big Unknown=1, Internet & CPU at home=1)
Pr(Big Unknown=1, Internet & CPU at home=0)
Pr(Missing=1, Internet & CPU at home=1)
Pr(Missing=1, Internet & CPU at home=0)
*/
gen augmen_i_y_cHH=pot_augmen*int_y_comp
gen augmen_ni_y_cHH=pot_augmen*nint_y_comp
gen automa_i_y_cHH=pot_automa*int_y_comp
gen automa_ni_y_cHH=pot_automa*nint_y_comp
gen unknown_i_y_cHH=pot_unknown*int_y_comp
gen unknown_ni_y_cHH=pot_unknown*nint_y_comp
gen missing_i_y_cHH=pot_missing*int_y_comp
gen missing_ni_y_cHH=pot_missing*nint_y_comp

* AI + Internet en casa O Computadora en casa
/*
Pr(Augmentation=1, Internet o CPU at home=1)
Pr(Augmentation=1, Internet o CPU at home=0)
Pr(Automation=1, Internet o CPU at home=1)
Pr(Automation=1, Internet o CPU at home=0)
Pr(Big Unknown=1, Internet o CPU at home=1)
Pr(Big Unknown=1, Internet o CPU at home=0)
Pr(Missing=1, Internet o CPU at home=1)
Pr(Missing=1, Internet o CPU at home=0)
*/
gen augmen_i_o_cHH=pot_augmen*int_o_comp
gen augmen_ni_o_cHH=pot_augmen*nint_o_comp
gen automa_i_o_cHH=pot_automa*int_o_comp
gen automa_ni_o_cHH=pot_automa*nint_o_comp
gen unknown_i_o_cHH=pot_unknown*int_o_comp
gen unknown_ni_o_cHH=pot_unknown*nint_o_comp
gen missing_i_o_cHH=pot_missing*int_o_comp
gen missing_ni_o_cHH=pot_missing*nint_o_comp


*** GENERATE VARIABLES FOR PROFILE 
* Variable g_edad
gen g_edad = 1 if edad>=15 & edad<=24 
replace g_edad = 2 if edad>=25 & edad<=34
replace g_edad = 3 if edad>=35 & edad<=44
replace g_edad = 4 if edad>=45 & edad<=54
replace g_edad = 5 if edad>=55 & edad<=64

* Variable pobre685
sort pais ano
merge pais ano using "$path\bases\Processed\ipc_sedlac_wb.dta", force keep(ppp17 ipc_sedlac ipc17_sedlac conversion)
ta _merge
keep if _merge==3
drop _merge

gen lp_685usd = (6.85*365/12)*ppp17*(ipc_sedlac/ipc17_sedlac)*conversion

gen pobre685 = 0 if ipcf!=.
replace pobre685 = 1 if ipcf<lp_685usd

* Variable qipcf
cuantiles ipcf [w=pondera] if ipcf>=0 & cohh==1, n(5) orden_aux(id com relacion edad) g(qipcf)

* Variable informal_1
gen     informal_1 = 0 if categ_lab==1
replace informal_1 = 1 if categ_lab==2

* Variable informal_2
gen     informal_2 = 1-djubila
replace informal_2 = . if asal!=1




*** PROFILES 

** PROFILE CPU
local potential_CPU = "augmen_compuHH augmen_ncompuHH automa_compuHH automa_ncompuHH unknown_compuHH unknown_ncompuHH missing_compuHH missing_ncompuHH"
mat `pais'_ai_CPUHH = J(8,38,.)

** PROFILE INTERNET
local potential_INT = "augmen_interHH augmen_ninterHH automa_interHH automa_ninterHH unknown_interHH unknown_ninterHH missing_interHH missing_ninterHH"
mat `pais'_ai_INTHH = J(8,38,.)

** PROFILE INTERNET & CPU
local potential_INTandCPU = "augmen_i_y_cHH augmen_ni_y_cHH automa_i_y_cHH automa_ni_y_cHH unknown_i_y_cHH unknown_ni_y_cHH missing_i_y_cHH missing_ni_y_cHH"
mat `pais'_ai_INTandCPUHH = J(8,38,.)

** PROFILE INTERNET OR CPU
local potential_INTorCPU = "augmen_i_o_cHH augmen_ni_o_cHH automa_i_o_cHH automa_ni_o_cHH unknown_i_o_cHH unknown_ni_o_cHH missing_i_o_cHH missing_ni_o_cHH"
mat `pais'_ai_INTorCPUHH = J(8,38,.)



** BUCLE PROFILE CPU
local cat = 1
foreach pot of local potential_CPU {

* TOTAL
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat `pais'_ai_CPUHH[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h'
mat `pais'_ai_CPUHH[`cat',2+`h']= r(mean)*100
}


* AREA (URBANO)
forvalues u =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u'
mat `pais'_ai_CPUHH[`cat',4+`u']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a'
mat `pais'_ai_CPUHH[`cat',5+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e'
mat `pais'_ai_CPUHH[`cat',10+`e']= r(mean)*100
}


* POVERTY
forvalues p =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p'
mat `pais'_ai_CPUHH[`cat',14+`p']= r(mean)*100
}


* QUINTIL (IPCF)
forvalues q =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q'
mat `pais'_ai_CPUHH[`cat',15+`q']= r(mean)*100
}


* LEGAL INFORMALITY (DJUBILA)
forvalues f =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f'
mat `pais'_ai_CPUHH[`cat',21+`f']= r(mean)*100
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
forvalues c =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c'
mat `pais'_ai_CPUHH[`cat',23+`c']= r(mean)*100
}

* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r'
mat `pais'_ai_CPUHH[`cat',24+`r']= r(mean)*100
}

* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'
mat `pais'_ai_CPUHH[`cat',28+`s']= r(mean)*100
}


local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}


** BUCLE PROFILE INTERNET
local cat = 1
foreach pot of local potential_INT {
 
* TOTAL
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat `pais'_ai_INTHH[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h'
mat `pais'_ai_INTHH[`cat',2+`h']= r(mean)*100
}


* AREA (URBANO)
forvalues u =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u'
mat `pais'_ai_INTHH[`cat',4+`u']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a'
mat `pais'_ai_INTHH[`cat',5+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e'
mat `pais'_ai_INTHH[`cat',10+`e']= r(mean)*100
}


* POVERTY
forvalues p =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p'
mat `pais'_ai_INTHH[`cat',14+`p']= r(mean)*100
}


* QUINTIL (IPCF)
forvalues q =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q'
mat `pais'_ai_INTHH[`cat',15+`q']= r(mean)*100
}


* LEGAL INFORMALITY (DJUBILA)
forvalues f =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f'
mat `pais'_ai_INTHH[`cat',21+`f']= r(mean)*100
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
forvalues c =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c'
mat `pais'_ai_INTHH[`cat',23+`c']= r(mean)*100
}

* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r'
mat `pais'_ai_INTHH[`cat',24+`r']= r(mean)*100
}

* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'
mat `pais'_ai_INTHH[`cat',28+`s']= r(mean)*100
}

local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}



** BUCLE PROFILE INTERNET & CPU
local cat = 1
foreach pot of local potential_INTandCPU {
  
* TOTAL
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat `pais'_ai_INTandCPUHH[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h'
mat `pais'_ai_INTandCPUHH[`cat',2+`h']= r(mean)*100
}


* AREA (URBANO)
forvalues u =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u'
mat `pais'_ai_INTandCPUHH[`cat',4+`u']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a'
mat `pais'_ai_INTandCPUHH[`cat',5+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e'
mat `pais'_ai_INTandCPUHH[`cat',10+`e']= r(mean)*100
}


* POVERTY
forvalues p =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p'
mat `pais'_ai_INTandCPUHH[`cat',14+`p']= r(mean)*100
}


* QUINTIL (IPCF)
forvalues q =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q'
mat `pais'_ai_INTandCPUHH[`cat',15+`q']= r(mean)*100
}


* LEGAL INFORMALITY (DJUBILA)
forvalues f =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f'
mat `pais'_ai_INTandCPUHH[`cat',21+`f']= r(mean)*100
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
forvalues c =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c'
mat `pais'_ai_INTandCPUHH[`cat',23+`c']= r(mean)*100
}

* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r'
mat `pais'_ai_INTandCPUHH[`cat',24+`r']= r(mean)*100
}

* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'
mat `pais'_ai_INTandCPUHH[`cat',28+`s']= r(mean)*100
}


local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}


** BUCLE PROFILE INTERNET Or CPU
local cat = 1
foreach pot of local potential_INTorCPU {
  
* TOTAL
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat `pais'_ai_INTorCPUHH[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h'
mat `pais'_ai_INTorCPUHH[`cat',2+`h']= r(mean)*100
}


* AREA (URBANO)
forvalues u =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u'
mat `pais'_ai_INTorCPUHH[`cat',4+`u']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a'
mat `pais'_ai_INTorCPUHH[`cat',5+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e'
mat `pais'_ai_INTorCPUHH[`cat',10+`e']= r(mean)*100
}


* POVERTY
forvalues p =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p'
mat `pais'_ai_INTorCPUHH[`cat',14+`p']= r(mean)*100
}


* QUINTIL (IPCF)
forvalues q =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q'
mat `pais'_ai_INTorCPUHH[`cat',15+`q']= r(mean)*100
}


* LEGAL INFORMALITY (DJUBILA)
forvalues f =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f'
mat `pais'_ai_INTorCPUHH[`cat',21+`f']= r(mean)*100
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
forvalues c =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c'
mat `pais'_ai_INTorCPUHH[`cat',23+`c']= r(mean)*100
}

* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r'
mat `pais'_ai_INTorCPUHH[`cat',24+`r']= r(mean)*100
}

* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'
mat `pais'_ai_INTorCPUHH[`cat',28+`s']= r(mean)*100
}

local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}


** CLOSE COUNTRY
}
mat dir



clear

*** Countries with ISCO 2d information, and matched with SEDLAC database of countries with ISCO 4d information
local base_in_1   "$path\bases\sedlac\ARG\ARG_2021_EPHC-S2_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_2   "$path\bases\sedlac\BOL\BOL_2021_EH_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_3   "$path\bases\sedlac\GTM\GTM_2014_ENCOVI_v02_M_v02_A_SEDLAC-03_all_ocupa.dta"
local base_in_4   "$path\bases\sedlac\NIC\NIC_2014_EMNV_v02_M_v02_A_SEDLAC-03_all.dta"


* Number of countries with ISCO 2d information
local t = 4

forvalue i = 1/`t'	{

use "`base_in_`i''", clear
di in ye "Base = `base_in_`i''"


* Argentina 2021 (2d)
if `i'==1 {
local pais = "arg"
local match = "ury"

destring isco08_2d, replace
}

* Bolivia 2021 (2d)
if `i'==2 {
local pais = "bol"
local match = "slv"

destring isco08_2d, replace
}

* Guatemala 2014 (2d)
if `i'==3 {
replace pais=lower(pais)

local pais = "gtm"
local match = "hnd"

destring isco08_2d, replace
}

* Nicaragua 2014 (2d)
if `i'==4 {
local pais = "nic"
local match = "hnd"

destring isco08_2d, replace
}


*** GENERATE VARIABLES FOR PROFILE 
* Variable g_edad
gen g_edad = 1 if edad>=15 & edad<=24 
replace g_edad = 2 if edad>=25 & edad<=34
replace g_edad = 3 if edad>=35 & edad<=44
replace g_edad = 4 if edad>=45 & edad<=54
replace g_edad = 5 if edad>=55 & edad<=64

* Variable pobre685
sort pais ano
merge pais ano using "$path\bases\Processed\ipc_sedlac_wb.dta", force keep(ppp17 ipc_sedlac ipc17_sedlac conversion)
ta _merge
keep if _merge==3
drop _merge

gen lp_685usd = (6.85*365/12)*ppp17*(ipc_sedlac/ipc17_sedlac)*conversion

gen pobre685 = 0 if ipcf!=.
replace pobre685 = 1 if ipcf<lp_685usd

* Variable qipcf
cuantiles ipcf [w=pondera] if ipcf>=0 & cohh==1, n(5) orden_aux(id com relacion edad) g(qipcf)

* Variable informal_1
gen     informal_1 = 0 if categ_lab==1
replace informal_1 = 1 if categ_lab==2

* Variable informal_2
gen     informal_2 = 1-djubila
replace informal_2 = . if asal!=1


** Merge to get potential (AI)
* Match with "`match'"
sort isco08_2d hombre 
ta pais
merge isco08_2d hombre using "$path\bases\Processed\matchISCO_`match'_SEDLAC.dta", force
ta _merge
keep if _merge==1 | _merge==3
drop _merge


* Genero variable computadora para todos los miembros del hogar
egen compu_hh = max(computadora), by(id)
gen ncompu_hh=1-compu_hh

* Genero variable internet_casa para todos los miembros del hogar
egen internet_hh = max(internet_casa), by(id)
gen ninternet_hh=1-internet_hh

* Genero variable internet_casa Y computadora
gen int_y_comp= compu_hh*internet_hh
gen nint_y_comp= 1-int_y_comp

* Genero variable internet_casa O computadora
gen int_o_comp= 1 if compu_hh==1 | internet_hh==1
replace int_o_comp= 0 if compu_hh==0 & internet_hh==0

summ compu_hh
local ncomp=r(N)
summ internet_hh
local nint=r(N)
if `ncomp'==0 | `nint'==0 {
capture drop int_o_comp
gen int_o_comp= .
}
gen nint_o_comp= 1-int_o_comp



** Generate variables to estimate probabilities
* AI + Computadora en casa
/*
Pr(Augmentation=1, Computer at home=1)
Pr(Augmentation=1, Computer at home=0)
Pr(Automation=1, Computer at home=1)
Pr(Automation=1, Computer at home=0)
Pr(Big Unknown=1, Computer at home=1)
Pr(Big Unknown=1, Computer at home=0)
Pr(Missing=1, Computer at home=1)
Pr(Missing=1, Computer at home=0)
*/
gen augmen_compuHH=exp_augmen_2d*compu_hh
gen augmen_ncompuHH=exp_augmen_2d*ncompu_hh
gen automa_compuHH=exp_automa_2d*compu_hh
gen automa_ncompuHH=exp_automa_2d*ncompu_hh
gen unknown_compuHH=exp_unknown_2d*compu_hh
gen unknown_ncompuHH=exp_unknown_2d*ncompu_hh
gen missing_compuHH=exp_missing_2d*compu_hh
gen missing_ncompuHH=exp_missing_2d*ncompu_hh

* AI + Internet en casa
/*
Pr(Augmentation=1, Internet at home=1)
Pr(Augmentation=1, Internet at home=0)
Pr(Automation=1, Internet at home=1)
Pr(Automation=1, Internet at home=0)
Pr(Big Unknown=1, Internet at home=1)
Pr(Big Unknown=1, Internet at home=0)
Pr(Missing=1, Internet at home=1)
Pr(Missing=1, Internet at home=0)
*/
gen augmen_interHH=exp_augmen_2d*internet_hh
gen augmen_ninterHH=exp_augmen_2d*ninternet_hh
gen automa_interHH=exp_automa_2d*internet_hh
gen automa_ninterHH=exp_automa_2d*ninternet_hh
gen unknown_interHH=exp_unknown_2d*internet_hh
gen unknown_ninterHH=exp_unknown_2d*ninternet_hh
gen missing_interHH=exp_missing_2d*internet_hh
gen missing_ninterHH=exp_missing_2d*ninternet_hh

* AI + Internet en casa & Computadora en casa
/*
Pr(Augmentation=1, Internet & CPU at home=1)
Pr(Augmentation=1, Internet & CPU at home=0)
Pr(Automation=1, Internet & CPU at home=1)
Pr(Automation=1, Internet & CPU at home=0)
Pr(Big Unknown=1, Internet & CPU at home=1)
Pr(Big Unknown=1, Internet & CPU at home=0)
Pr(Missing=1, Internet & CPU at home=1)
Pr(Missing=1, Internet & CPU at home=0)
*/
gen augmen_i_y_cHH=exp_augmen_2d*int_y_comp
gen augmen_ni_y_cHH=exp_augmen_2d*nint_y_comp
gen automa_i_y_cHH=exp_automa_2d*int_y_comp
gen automa_ni_y_cHH=exp_automa_2d*nint_y_comp
gen unknown_i_y_cHH=exp_unknown_2d*int_y_comp
gen unknown_ni_y_cHH=exp_unknown_2d*nint_y_comp
gen missing_i_y_cHH=exp_missing_2d*int_y_comp
gen missing_ni_y_cHH=exp_missing_2d*nint_y_comp

* AI + Internet en casa O Computadora en casa
/*
Pr(Augmentation=1, Internet o CPU at home=1)
Pr(Augmentation=1, Internet o CPU at home=0)
Pr(Automation=1, Internet o CPU at home=1)
Pr(Automation=1, Internet o CPU at home=0)
Pr(Big Unknown=1, Internet o CPU at home=1)
Pr(Big Unknown=1, Internet o CPU at home=0)
Pr(Missing=1, Internet o CPU at home=1)
Pr(Missing=1, Internet o CPU at home=0)
*/
gen augmen_i_o_cHH=exp_augmen_2d*int_o_comp
gen augmen_ni_o_cHH=exp_augmen_2d*nint_o_comp
gen automa_i_o_cHH=exp_automa_2d*int_o_comp
gen automa_ni_o_cHH=exp_automa_2d*nint_o_comp
gen unknown_i_o_cHH=exp_unknown_2d*int_o_comp
gen unknown_ni_o_cHH=exp_unknown_2d*nint_o_comp
gen missing_i_o_cHH=exp_missing_2d*int_o_comp
gen missing_ni_o_cHH=exp_missing_2d*nint_o_comp



*** PROFILES 

** PROFILE CPU
local potential_CPU = "augmen_compuHH augmen_ncompuHH automa_compuHH automa_ncompuHH unknown_compuHH unknown_ncompuHH missing_compuHH missing_ncompuHH"
mat `pais'_ai_CPUHH = J(8,38,.)

** PROFILE INTERNET
local potential_INT = "augmen_interHH augmen_ninterHH automa_interHH automa_ninterHH unknown_interHH unknown_ninterHH missing_interHH missing_ninterHH"
mat `pais'_ai_INTHH = J(8,38,.)

** PROFILE INTERNET & CPU
local potential_INTandCPU = "augmen_i_y_cHH augmen_ni_y_cHH automa_i_y_cHH automa_ni_y_cHH unknown_i_y_cHH unknown_ni_y_cHH missing_i_y_cHH missing_ni_y_cHH"
mat `pais'_ai_INTandCPUHH = J(8,38,.)

** PROFILE INTERNET OR CPU
local potential_INTorCPU = "augmen_i_o_cHH augmen_ni_o_cHH automa_i_o_cHH automa_ni_o_cHH unknown_i_o_cHH unknown_ni_o_cHH missing_i_o_cHH missing_ni_o_cHH"
mat `pais'_ai_INTorCPUHH = J(8,38,.)



** BUCLE PROFILE CPU
local cat = 1
foreach pot of local potential_CPU {

* TOTAL
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat `pais'_ai_CPUHH[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h'
mat `pais'_ai_CPUHH[`cat',2+`h']= r(mean)*100
}


* AREA (URBANO)
forvalues u =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u'
mat `pais'_ai_CPUHH[`cat',4+`u']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a'
mat `pais'_ai_CPUHH[`cat',5+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e'
mat `pais'_ai_CPUHH[`cat',10+`e']= r(mean)*100
}


* POVERTY
forvalues p =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p'
mat `pais'_ai_CPUHH[`cat',14+`p']= r(mean)*100
}


* QUINTIL (IPCF)
forvalues q =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q'
mat `pais'_ai_CPUHH[`cat',15+`q']= r(mean)*100
}


* LEGAL INFORMALITY (DJUBILA)
forvalues f =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f'
mat `pais'_ai_CPUHH[`cat',21+`f']= r(mean)*100
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
forvalues c =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c'
mat `pais'_ai_CPUHH[`cat',23+`c']= r(mean)*100
}

* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r'
mat `pais'_ai_CPUHH[`cat',24+`r']= r(mean)*100
}

* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'
mat `pais'_ai_CPUHH[`cat',28+`s']= r(mean)*100
}


local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}


** BUCLE PROFILE INTERNET
local cat = 1
foreach pot of local potential_INT {
 
* TOTAL
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat `pais'_ai_INTHH[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h'
mat `pais'_ai_INTHH[`cat',2+`h']= r(mean)*100
}


* AREA (URBANO)
forvalues u =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u'
mat `pais'_ai_INTHH[`cat',4+`u']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a'
mat `pais'_ai_INTHH[`cat',5+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e'
mat `pais'_ai_INTHH[`cat',10+`e']= r(mean)*100
}


* POVERTY
forvalues p =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p'
mat `pais'_ai_INTHH[`cat',14+`p']= r(mean)*100
}


* QUINTIL (IPCF)
forvalues q =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q'
mat `pais'_ai_INTHH[`cat',15+`q']= r(mean)*100
}


* LEGAL INFORMALITY (DJUBILA)
forvalues f =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f'
mat `pais'_ai_INTHH[`cat',21+`f']= r(mean)*100
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
forvalues c =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c'
mat `pais'_ai_INTHH[`cat',23+`c']= r(mean)*100
}

* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r'
mat `pais'_ai_INTHH[`cat',24+`r']= r(mean)*100
}

* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'
mat `pais'_ai_INTHH[`cat',28+`s']= r(mean)*100
}

local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}



** BUCLE PROFILE INTERNET & CPU
local cat = 1
foreach pot of local potential_INTandCPU {
  
* TOTAL
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat `pais'_ai_INTandCPUHH[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h'
mat `pais'_ai_INTandCPUHH[`cat',2+`h']= r(mean)*100
}


* AREA (URBANO)
forvalues u =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u'
mat `pais'_ai_INTandCPUHH[`cat',4+`u']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a'
mat `pais'_ai_INTandCPUHH[`cat',5+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e'
mat `pais'_ai_INTandCPUHH[`cat',10+`e']= r(mean)*100
}


* POVERTY
forvalues p =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p'
mat `pais'_ai_INTandCPUHH[`cat',14+`p']= r(mean)*100
}


* QUINTIL (IPCF)
forvalues q =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q'
mat `pais'_ai_INTandCPUHH[`cat',15+`q']= r(mean)*100
}


* LEGAL INFORMALITY (DJUBILA)
forvalues f =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f'
mat `pais'_ai_INTandCPUHH[`cat',21+`f']= r(mean)*100
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
forvalues c =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c'
mat `pais'_ai_INTandCPUHH[`cat',23+`c']= r(mean)*100
}

* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r'
mat `pais'_ai_INTandCPUHH[`cat',24+`r']= r(mean)*100
}

* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'
mat `pais'_ai_INTandCPUHH[`cat',28+`s']= r(mean)*100
}


local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}


** BUCLE PROFILE INTERNET Or CPU
local cat = 1
foreach pot of local potential_INTorCPU {
  
* TOTAL
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat `pais'_ai_INTorCPUHH[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h'
mat `pais'_ai_INTorCPUHH[`cat',2+`h']= r(mean)*100
}


* AREA (URBANO)
forvalues u =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u'
mat `pais'_ai_INTorCPUHH[`cat',4+`u']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a'
mat `pais'_ai_INTorCPUHH[`cat',5+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e'
mat `pais'_ai_INTorCPUHH[`cat',10+`e']= r(mean)*100
}


* POVERTY
forvalues p =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p'
mat `pais'_ai_INTorCPUHH[`cat',14+`p']= r(mean)*100
}


* QUINTIL (IPCF)
forvalues q =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q'
mat `pais'_ai_INTorCPUHH[`cat',15+`q']= r(mean)*100
}


* LEGAL INFORMALITY (DJUBILA)
forvalues f =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f'
mat `pais'_ai_INTorCPUHH[`cat',21+`f']= r(mean)*100
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
forvalues c =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c'
mat `pais'_ai_INTorCPUHH[`cat',23+`c']= r(mean)*100
}

* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r'
mat `pais'_ai_INTorCPUHH[`cat',24+`r']= r(mean)*100
}

* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'
mat `pais'_ai_INTorCPUHH[`cat',28+`s']= r(mean)*100
}

local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}


** CLOSE COUNTRY
}
mat dir



clear

*** Countries with ISCO 2d information, and matched with ILO & WB database
local base_in_1   "$path\bases\sedlac\BRA\BRA_2021_PNADC-E5_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_2   "$path\bases\sedlac\COL\COL_2019_GEIH_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_3   "$path\bases\sedlac\CRI\CRI_2019_ENAHO_v02_M_v02_A_SEDLAC-03_all.dta"
local base_in_4   "$path\bases\sedlac\MEX\MEX_2018_ENIGHNS_v02_M_v02_A_SEDLAC-03_all.dta"


* Number of countries with ISCO 2d information
local t = 4

forvalue i = 1/`t'	{

use "`base_in_`i''", clear
di in ye "Base = `base_in_`i''"


* Brazil 2021 (2d)
if `i'==1 {
local pais = "bra"

destring isco08_2d, replace
}

* Colombia 2019 (2d)
if `i'==2 {
local pais = "col"

destring isco08_2d, replace
}

* Costa Rica 2019 (2d)
if `i'==3 {
local pais = "cri"

destring isco08_2d, replace
}

* Mexico 2018 (2d)
if `i'==4 {
local pais = "mex"

destring isco08_2d, replace
}

*** GENERATE VARIABLES FOR PROFILE 
* Variable g_edad
gen g_edad = 1 if edad>=15 & edad<=24 
replace g_edad = 2 if edad>=25 & edad<=34
replace g_edad = 3 if edad>=35 & edad<=44
replace g_edad = 4 if edad>=45 & edad<=54
replace g_edad = 5 if edad>=55 & edad<=64

* Variable pobre685
sort pais ano
merge pais ano using "$path\bases\Processed\ipc_sedlac_wb.dta", force keep(ppp17 ipc_sedlac ipc17_sedlac conversion)
ta _merge
keep if _merge==3
drop _merge

gen lp_685usd = (6.85*365/12)*ppp17*(ipc_sedlac/ipc17_sedlac)*conversion

gen pobre685 = 0 if ipcf!=.
replace pobre685 = 1 if ipcf<lp_685usd

* Variable qipcf
cuantiles ipcf [w=pondera] if ipcf>=0 & cohh==1, n(5) orden_aux(id com relacion edad) g(qipcf)

* Variable informal_1
gen     informal_1 = 0 if categ_lab==1
replace informal_1 = 1 if categ_lab==2

* Variable informal_2
gen     informal_2 = 1-djubila
replace informal_2 = . if asal!=1


* Pequeña modificación dado que para calcular los shares en la base de ILO WB se contempla a los ocupados con missing en ISCO 
replace isco08_2d=999 if ocupado==1 & isco08_2d==. 



* Match with data from the same country using ILO & WB database
ta pais
sort pais isco08_2d hombre
merge pais isco08_2d hombre using "$path\bases\Processed\matchISCO_ILOWB.dta", force
ta _merge
keep if _merge==1 | _merge==3
drop _merge


replace exp_augmen_2d = 0 if exp_augmen_2d==.
replace exp_automa_2d = 0 if exp_automa_2d==.
replace exp_unknown_2d = 0 if exp_unknown_2d==.
gen exp_missing_2d = 1-exp_augmen_2d-exp_automa_2d-exp_unknown_2d


* Genero variable computadora para todos los miembros del hogar
egen compu_hh = max(computadora), by(id)
gen ncompu_hh=1-compu_hh

* Genero variable internet_casa para todos los miembros del hogar
egen internet_hh = max(internet_casa), by(id)
gen ninternet_hh=1-internet_hh

* Genero variable internet_casa Y computadora
gen int_y_comp= compu_hh*internet_hh
gen nint_y_comp= 1-int_y_comp

* Genero variable internet_casa O computadora
gen int_o_comp= 1 if compu_hh==1 | internet_hh==1
replace int_o_comp= 0 if compu_hh==0 & internet_hh==0

summ compu_hh
local ncomp=r(N)
summ internet_hh
local nint=r(N)
if `ncomp'==0 | `nint'==0 {
capture drop int_o_comp
gen int_o_comp= .
}
gen nint_o_comp= 1-int_o_comp



** Generate variables to estimate probabilities
* AI + Computadora en casa
/*
Pr(Augmentation=1, Computer at home=1)
Pr(Augmentation=1, Computer at home=0)
Pr(Automation=1, Computer at home=1)
Pr(Automation=1, Computer at home=0)
Pr(Big Unknown=1, Computer at home=1)
Pr(Big Unknown=1, Computer at home=0)
Pr(Missing=1, Computer at home=1)
Pr(Missing=1, Computer at home=0)
*/
gen augmen_compuHH=exp_augmen_2d*compu_hh
gen augmen_ncompuHH=exp_augmen_2d*ncompu_hh
gen automa_compuHH=exp_automa_2d*compu_hh
gen automa_ncompuHH=exp_automa_2d*ncompu_hh
gen unknown_compuHH=exp_unknown_2d*compu_hh
gen unknown_ncompuHH=exp_unknown_2d*ncompu_hh
gen missing_compuHH=exp_missing_2d*compu_hh
gen missing_ncompuHH=exp_missing_2d*ncompu_hh

* AI + Internet en casa
/*
Pr(Augmentation=1, Internet at home=1)
Pr(Augmentation=1, Internet at home=0)
Pr(Automation=1, Internet at home=1)
Pr(Automation=1, Internet at home=0)
Pr(Big Unknown=1, Internet at home=1)
Pr(Big Unknown=1, Internet at home=0)
Pr(Missing=1, Internet at home=1)
Pr(Missing=1, Internet at home=0)
*/
gen augmen_interHH=exp_augmen_2d*internet_hh
gen augmen_ninterHH=exp_augmen_2d*ninternet_hh
gen automa_interHH=exp_automa_2d*internet_hh
gen automa_ninterHH=exp_automa_2d*ninternet_hh
gen unknown_interHH=exp_unknown_2d*internet_hh
gen unknown_ninterHH=exp_unknown_2d*ninternet_hh
gen missing_interHH=exp_missing_2d*internet_hh
gen missing_ninterHH=exp_missing_2d*ninternet_hh

* AI + Internet en casa & Computadora en casa
/*
Pr(Augmentation=1, Internet & CPU at home=1)
Pr(Augmentation=1, Internet & CPU at home=0)
Pr(Automation=1, Internet & CPU at home=1)
Pr(Automation=1, Internet & CPU at home=0)
Pr(Big Unknown=1, Internet & CPU at home=1)
Pr(Big Unknown=1, Internet & CPU at home=0)
Pr(Missing=1, Internet & CPU at home=1)
Pr(Missing=1, Internet & CPU at home=0)
*/
gen augmen_i_y_cHH=exp_augmen_2d*int_y_comp
gen augmen_ni_y_cHH=exp_augmen_2d*nint_y_comp
gen automa_i_y_cHH=exp_automa_2d*int_y_comp
gen automa_ni_y_cHH=exp_automa_2d*nint_y_comp
gen unknown_i_y_cHH=exp_unknown_2d*int_y_comp
gen unknown_ni_y_cHH=exp_unknown_2d*nint_y_comp
gen missing_i_y_cHH=exp_missing_2d*int_y_comp
gen missing_ni_y_cHH=exp_missing_2d*nint_y_comp

* AI + Internet en casa O Computadora en casa
/*
Pr(Augmentation=1, Internet o CPU at home=1)
Pr(Augmentation=1, Internet o CPU at home=0)
Pr(Automation=1, Internet o CPU at home=1)
Pr(Automation=1, Internet o CPU at home=0)
Pr(Big Unknown=1, Internet o CPU at home=1)
Pr(Big Unknown=1, Internet o CPU at home=0)
Pr(Missing=1, Internet o CPU at home=1)
Pr(Missing=1, Internet o CPU at home=0)
*/
gen augmen_i_o_cHH=exp_augmen_2d*int_o_comp
gen augmen_ni_o_cHH=exp_augmen_2d*nint_o_comp
gen automa_i_o_cHH=exp_automa_2d*int_o_comp
gen automa_ni_o_cHH=exp_automa_2d*nint_o_comp
gen unknown_i_o_cHH=exp_unknown_2d*int_o_comp
gen unknown_ni_o_cHH=exp_unknown_2d*nint_o_comp
gen missing_i_o_cHH=exp_missing_2d*int_o_comp
gen missing_ni_o_cHH=exp_missing_2d*nint_o_comp



*** PROFILES 

** PROFILE CPU
local potential_CPU = "augmen_compuHH augmen_ncompuHH automa_compuHH automa_ncompuHH unknown_compuHH unknown_ncompuHH missing_compuHH missing_ncompuHH"
mat `pais'_ai_CPUHH = J(8,38,.)

** PROFILE INTERNET
local potential_INT = "augmen_interHH augmen_ninterHH automa_interHH automa_ninterHH unknown_interHH unknown_ninterHH missing_interHH missing_ninterHH"
mat `pais'_ai_INTHH = J(8,38,.)

** PROFILE INTERNET & CPU
local potential_INTandCPU = "augmen_i_y_cHH augmen_ni_y_cHH automa_i_y_cHH automa_ni_y_cHH unknown_i_y_cHH unknown_ni_y_cHH missing_i_y_cHH missing_ni_y_cHH"
mat `pais'_ai_INTandCPUHH = J(8,38,.)

** PROFILE INTERNET OR CPU
local potential_INTorCPU = "augmen_i_o_cHH augmen_ni_o_cHH automa_i_o_cHH automa_ni_o_cHH unknown_i_o_cHH unknown_ni_o_cHH missing_i_o_cHH missing_ni_o_cHH"
mat `pais'_ai_INTorCPUHH = J(8,38,.)



** BUCLE PROFILE CPU
local cat = 1
foreach pot of local potential_CPU {

* TOTAL
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat `pais'_ai_CPUHH[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h'
mat `pais'_ai_CPUHH[`cat',2+`h']= r(mean)*100
}


* AREA (URBANO)
forvalues u =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u'
mat `pais'_ai_CPUHH[`cat',4+`u']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a'
mat `pais'_ai_CPUHH[`cat',5+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e'
mat `pais'_ai_CPUHH[`cat',10+`e']= r(mean)*100
}


* POVERTY
forvalues p =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p'
mat `pais'_ai_CPUHH[`cat',14+`p']= r(mean)*100
}


* QUINTIL (IPCF)
forvalues q =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q'
mat `pais'_ai_CPUHH[`cat',15+`q']= r(mean)*100
}


* LEGAL INFORMALITY (DJUBILA)
forvalues f =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f'
mat `pais'_ai_CPUHH[`cat',21+`f']= r(mean)*100
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
forvalues c =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c'
mat `pais'_ai_CPUHH[`cat',23+`c']= r(mean)*100
}

* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r'
mat `pais'_ai_CPUHH[`cat',24+`r']= r(mean)*100
}

* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'
mat `pais'_ai_CPUHH[`cat',28+`s']= r(mean)*100
}


local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}


** BUCLE PROFILE INTERNET
local cat = 1
foreach pot of local potential_INT {
 
* TOTAL
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat `pais'_ai_INTHH[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h'
mat `pais'_ai_INTHH[`cat',2+`h']= r(mean)*100
}


* AREA (URBANO)
forvalues u =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u'
mat `pais'_ai_INTHH[`cat',4+`u']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a'
mat `pais'_ai_INTHH[`cat',5+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e'
mat `pais'_ai_INTHH[`cat',10+`e']= r(mean)*100
}


* POVERTY
forvalues p =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p'
mat `pais'_ai_INTHH[`cat',14+`p']= r(mean)*100
}


* QUINTIL (IPCF)
forvalues q =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q'
mat `pais'_ai_INTHH[`cat',15+`q']= r(mean)*100
}


* LEGAL INFORMALITY (DJUBILA)
forvalues f =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f'
mat `pais'_ai_INTHH[`cat',21+`f']= r(mean)*100
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
forvalues c =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c'
mat `pais'_ai_INTHH[`cat',23+`c']= r(mean)*100
}

* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r'
mat `pais'_ai_INTHH[`cat',24+`r']= r(mean)*100
}

* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'
mat `pais'_ai_INTHH[`cat',28+`s']= r(mean)*100
}


local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}



** BUCLE PROFILE INTERNET & CPU
local cat = 1
foreach pot of local potential_INTandCPU {
  
* TOTAL
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat `pais'_ai_INTandCPUHH[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h'
mat `pais'_ai_INTandCPUHH[`cat',2+`h']= r(mean)*100
}


* AREA (URBANO)
forvalues u =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u'
mat `pais'_ai_INTandCPUHH[`cat',4+`u']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a'
mat `pais'_ai_INTandCPUHH[`cat',5+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e'
mat `pais'_ai_INTandCPUHH[`cat',10+`e']= r(mean)*100
}


* POVERTY
forvalues p =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p'
mat `pais'_ai_INTandCPUHH[`cat',14+`p']= r(mean)*100
}


* QUINTIL (IPCF)
forvalues q =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q'
mat `pais'_ai_INTandCPUHH[`cat',15+`q']= r(mean)*100
}


* LEGAL INFORMALITY (DJUBILA)
forvalues f =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f'
mat `pais'_ai_INTandCPUHH[`cat',21+`f']= r(mean)*100
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
forvalues c =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c'
mat `pais'_ai_INTandCPUHH[`cat',23+`c']= r(mean)*100
}

* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r'
mat `pais'_ai_INTandCPUHH[`cat',24+`r']= r(mean)*100
}

* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'
mat `pais'_ai_INTandCPUHH[`cat',28+`s']= r(mean)*100
}


local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}


** BUCLE PROFILE INTERNET Or CPU
local cat = 1
foreach pot of local potential_INTorCPU {
  
* TOTAL
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat `pais'_ai_INTorCPUHH[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h'
mat `pais'_ai_INTorCPUHH[`cat',2+`h']= r(mean)*100
}


* AREA (URBANO)
forvalues u =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u'
mat `pais'_ai_INTorCPUHH[`cat',4+`u']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a'
mat `pais'_ai_INTorCPUHH[`cat',5+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e'
mat `pais'_ai_INTorCPUHH[`cat',10+`e']= r(mean)*100
}


* POVERTY
forvalues p =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p'
mat `pais'_ai_INTorCPUHH[`cat',14+`p']= r(mean)*100
}


* QUINTIL (IPCF)
forvalues q =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q'
mat `pais'_ai_INTorCPUHH[`cat',15+`q']= r(mean)*100
}


* LEGAL INFORMALITY (DJUBILA)
forvalues f =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f'
mat `pais'_ai_INTorCPUHH[`cat',21+`f']= r(mean)*100
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
forvalues c =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c'
mat `pais'_ai_INTorCPUHH[`cat',23+`c']= r(mean)*100
}

* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r'
mat `pais'_ai_INTorCPUHH[`cat',24+`r']= r(mean)*100
}

* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'
mat `pais'_ai_INTorCPUHH[`cat',28+`s']= r(mean)*100
}


local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}

** CLOSE COUNTRY
}
mat dir


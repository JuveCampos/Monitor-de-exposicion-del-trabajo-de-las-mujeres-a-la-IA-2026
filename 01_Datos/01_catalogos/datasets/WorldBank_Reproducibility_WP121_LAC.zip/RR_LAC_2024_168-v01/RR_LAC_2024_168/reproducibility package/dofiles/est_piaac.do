********** MATRIZ DE DATA ******** 
mat TOT1 = bel_ai_cpu \ chl_ai_cpu \ cze_ai_cpu \ dnk_ai_cpu \ ecu_ai_cpu \ esp_ai_cpu \ fra_ai_cpu \ gbr_ai_cpu \    ///
grc_ai_cpu \ hun_ai_cpu \ isr_ai_cpu \ ita_ai_cpu \ jpn_ai_cpu \ kaz_ai_cpu \ kor_ai_cpu \ ltu_ai_cpu \ mex_ai_cpu \ ///
nld_ai_cpu \ nzl_ai_cpu \ per_ai_cpu \ pol_ai_cpu \ rus_ai_cpu \ svk_ai_cpu \ svn_ai_cpu \ tur_ai_cpu

/*
mat TOT2 = bel_ai_int \ chl_ai_int \ cze_ai_int \ dnk_ai_int \ ecu_ai_int \ esp_ai_int \ fra_ai_int \ gbr_ai_int \    ///
grc_ai_int \ hun_ai_int \ isr_ai_int \ ita_ai_int \ jpn_ai_int \ kaz_ai_int \ kor_ai_int \ ltu_ai_int \ mex_ai_int \ ///
nld_ai_int \ nzl_ai_int \ per_ai_int \ pol_ai_int \ rus_ai_int \ svk_ai_int \ svn_ai_int \ tur_ai_int
*/

********* TRANSFERENCIA A XLS *********
drop _all
svmat double TOT1
outsheet using "$path_xls\ai_piaac_only_cpu.xls", replace

/*
drop _all
svmat double TOT2
outsheet using "$path_xls\ai_piaac_only.xls", replace
*/
********* CIERRA *********
mat drop _all
clear

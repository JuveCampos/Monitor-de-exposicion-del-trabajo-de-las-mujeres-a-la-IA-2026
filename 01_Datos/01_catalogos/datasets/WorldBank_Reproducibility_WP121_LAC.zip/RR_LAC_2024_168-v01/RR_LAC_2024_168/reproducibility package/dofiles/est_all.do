********** MATRIZ DE DATA ******** 
mat TOT = arg_ai \ bol_ai \ bra_ai \ chl_ai \ col_ai \ cri_ai \ dom_ai \ ecu_ai \ gtm_ai \ hnd_ai \ mex_ai \ nic_ai \ pan_ai \ per_ai \ slv_ai \ ury_ai

********* TRANSFERENCIA A XLS *********
drop _all
svmat double TOT
outsheet using "$path_xls\isco_ai_all.xls", replace

********* CIERRA *********
mat drop _all
clear

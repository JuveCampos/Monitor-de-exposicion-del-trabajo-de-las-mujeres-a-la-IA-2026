*** Prepare database to estimate potential AI 

insheet using "$path\bases\ILO\Gmyrek_Berg_Bescond_scores_2023.csv", clear comma

tab potential
rename isco_08 isco08_4d

sort isco08_4d
saveold "$path\bases\Processed\ILO_db.dta", replace 


*** Prepare database to estimate poverty using international poverty lines
use "$path\bases\PPP_Poverty_SEDLAC\ipc_sedlac_wb.dta", clear 

sort pais ano

saveold "$path\bases\Processed\ipc_sedlac_wb.dta", replace 



*** Database prepared by ILO & WB based on “Gmyrek, Berg and Bescond (2023)” data
*** It contains AI exposure scores by 2-digit ISCO-08 occupations and gender, in order to match with some SEDLAC countries with 2-digit ISCO-08 data
insheet using "$path\bases\ILO\Microdata_ILO\LATAM_FINAL_ILO_data.csv", clear comma

keep if code=="BRA" | code=="COL" | code=="CRI" | code=="MEX"
drop if sex=="Total"
 
* PAIS
gen pais = lower(code)
drop code

* HOMBRE
gen hombre = 0 if sex=="Female"
replace hombre = 1 if sex=="Male"
drop sex

* ISCO 2d
encode isco2d, gen(aux)
gen isco08_2d = aux
replace isco08_2d = 7+aux if aux>=4 & aux<=7
replace isco08_2d = 13+aux if aux>=8 & aux<=13
replace isco08_2d = 17+aux if aux>=14 & aux<=18
replace isco08_2d = 22+aux if aux>=19 & aux<=22
replace isco08_2d = 28+aux if aux>=23 & aux<=26
replace isco08_2d = 34+aux if aux>=27 & aux<=29
replace isco08_2d = 41+aux if aux>=30 & aux<=34
replace isco08_2d = 46+aux if aux>=35 & aux<=37
replace isco08_2d = 53+aux if aux>=38 & aux<=43
replace isco08_2d = 999    if aux==44
drop aux isco2d


replace augmentation_isco="" if augmentation_isco=="NA"
replace automation_isco="" if automation_isco=="NA"
replace unknown_isco="" if unknown_isco=="NA"

destring augmentation_isco, replace
destring automation_isco, replace
destring unknown_isco, replace

* AI EXPOSURE
gen exp_augmen_2d = augmentation_isco
gen exp_automa_2d = automation_isco
gen exp_unknown_2d = unknown_isco

keep pais isco08_2d hombre exp_augmen_2d exp_automa_2d exp_unknown_2d
order pais isco08_2d hombre exp_augmen_2d exp_automa_2d exp_unknown_2d

sort pais isco08_2d hombre
saveold "$path\bases\Processed\matchISCO_ILOWB.dta", replace



*** Prepare database for countries with 4-digit ISCO-08 information (SEDLAC), in order to match with countries with 2-digit ISCO-08 information 
local base_in_1   "$path\bases\sedlac\CHL\CHL_2022_CASEN_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_2   "$path\bases\sedlac\DOM\DOM_2021_ECNFT_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_3   "$path\bases\sedlac\ECU\ECU_2021_ENEMDU_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_4   "$path\bases\sedlac\HND\HND_2019_EPHPM_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_5   "$path\bases\sedlac\PAN\PAN_2018_EH_v01_M_v05_A_SEDLAC-03_all.dta"
local base_in_6   "$path\bases\sedlac\PER\PER_2021_ENAHO_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_7   "$path\bases\sedlac\SLV\SLV_2021_EHPM_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_8   "$path\bases\sedlac\URY\URY_2021_ECH-S2_v01_M_v01_A_SEDLAC-03_all.dta"



* Number of countries
local t = 8


forvalue i = 1/`t'	{

use "`base_in_`i''", clear
di in ye "Base = `base_in_`i''"


if `i'==1 {
local pais = "chl"

replace isco08_4d = "." if  isco08_4d == "0-66"
replace isco08_4d = "." if  isco08_4d == "0-88"
replace isco08_4d = "." if  isco08_4d == "0-99"

destring isco08_4d, replace 

* Calculos a 2 dígitos
replace isco08_2d="" if isco08_2d=="0-"
destring isco08_2d, replace
summ isco* 
}


* República Dominicana 2021 (4d)
if `i'==2 {
local pais = "dom"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Ecuador 2021 (4d)
if `i'==3 {
local pais = "ecu"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Honduras 2019 (4d)
if `i'==4 {
local pais = "hnd"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Panama 2018 (4d)
if `i'==5 {
local pais = "pan"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Peru 2021 (4d)
if `i'==6 {
local pais = "per"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* El Salvador 2021 (4d)
if `i'==7 {
local pais = "slv"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Uruguay 2021 (4d)
if `i'==8 {
local pais = "ury"

replace isco08_4d = "." if  isco08_4d == "0"
destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}



* Merge con base ILO
sort isco08_4d
merge isco08_4d using "$path\bases\Processed\ILO_db.dta", force
ta _merge
keep if _merge==1 | _merge==3
drop _merge

ta potential, g(pot_)
rename pot_1 augmen
rename pot_2 automa
rename pot_3 unknown
rename pot_4 missing

ta potential [w=pondera] if ocupado==1 & edad>=15 & edad<=64

version 14: table isco08_4d [w=pondera] if ocupado==1 & edad>=15 & edad<=64, c(freq min augmen min automa min unknown min missing)

** ARMA base by gender
forvalues g=0(1)1 {
preserve 
version 14: table isco08_4d [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & hombre==`g', c(freq min augmen min automa min unknown min missing) replace
rename table1 workers
rename table2 augmen
rename table3 automa
rename table4 unknown
rename table5 missing
drop if augmen==. & automa==. & unknown==. & missing==.

local vars "augmen automa unknown missing"

foreach var of local vars {
gen w_`var' = workers*`var' 
}

gen isco08_2d= round((isco08_4d/100)-0.5)

bysort isco08_2d: egen w_tot_isco2d=total(workers)
bysort isco08_2d: egen w_augmen_isco2d=total(w_augmen)
bysort isco08_2d: egen w_automa_isco2d=total(w_automa)
bysort isco08_2d: egen w_unknown_isco2d=total(w_unknown)
bysort isco08_2d: egen w_missing_isco2d=total(w_missing)

foreach var of local vars {
gen exp_`var'_2d = w_`var'_isco2d / w_tot_isco2d
}


* Base final
keep isco08_2d exp_augmen_2d exp_automa_2d exp_unknown_2d exp_missing_2d 
collapse exp_augmen_2d exp_automa_2d exp_unknown_2d exp_missing_2d, by(isco08_2d)
order isco08_2d
gen hombre=`g'
sort isco08_2d

tempfile `pais'_hombre`g'
save ``pais'_hombre`g'', replace

*saveold "$path\bases\match_isco\matchISCO_`pais'_hombre`g'.dta", replace 
restore
}

use ``pais'_hombre0', clear
append using ``pais'_hombre1'

order isco08_2d hombre
sort isco08_2d hombre

*saveold "$path\bases\match_isco_sedlac\matchISCO_`pais'_SEDLAC.dta", replace 
saveold "$path\bases\Processed\matchISCO_`pais'_SEDLAC.dta", replace

}

* We keep only with the databases from HND, SLV and URY
erase "$path\bases\Processed\matchISCO_chl_SEDLAC.dta"
erase "$path\bases\Processed\matchISCO_dom_SEDLAC.dta"
erase "$path\bases\Processed\matchISCO_ecu_SEDLAC.dta"
erase "$path\bases\Processed\matchISCO_pan_SEDLAC.dta"
erase "$path\bases\Processed\matchISCO_per_SEDLAC.dta"


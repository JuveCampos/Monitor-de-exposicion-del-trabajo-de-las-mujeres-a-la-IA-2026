********** MATRIZ DE DATA ******** 
mat TOT = arg_ai_comp \ bol_ai_comp \ bra_ai_comp \ chl_ai_comp \ col_ai_comp \ cri_ai_comp \ dom_ai_comp \ ecu_ai_comp \ gtm_ai_comp \ hnd_ai_comp \ mex_ai_comp \ nic_ai_comp \ pan_ai_comp \ per_ai_comp \ slv_ai_comp \ ury_ai_comp
mat TOT1 = arg_ai_int \ bol_ai_int \ bra_ai_int \ chl_ai_int \ col_ai_int \ cri_ai_int \ dom_ai_int \ ecu_ai_int \ gtm_ai_int \ hnd_ai_int \ mex_ai_int \ nic_ai_int \ pan_ai_int \ per_ai_int \ slv_ai_int \ ury_ai_int

********* TRANSFERENCIA A XLS *********
drop _all
svmat double TOT
outsheet using "$path_xls\ai_sedlac_piaac_comp.xls", replace


drop _all
svmat double TOT1
outsheet using "$path_xls\ai_sedlac_piaac_int.xls", replace

********* CIERRA *********
mat drop _all
clear

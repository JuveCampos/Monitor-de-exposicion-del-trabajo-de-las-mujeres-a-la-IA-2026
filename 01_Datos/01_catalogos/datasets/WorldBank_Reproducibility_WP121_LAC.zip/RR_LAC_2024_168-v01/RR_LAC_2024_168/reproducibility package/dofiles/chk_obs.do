local base_in_1   "$path\bases\sedlac\ARG\ARG_2021_EPHC-S2_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_2   "$path\bases\sedlac\BOL\BOL_2021_EH_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_3   "$path\bases\sedlac\BRA\BRA_2021_PNADC-E5_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_4   "$path\bases\sedlac\CHL\CHL_2022_CASEN_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_5   "$path\bases\sedlac\COL\COL_2019_GEIH_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_6   "$path\bases\sedlac\CRI\CRI_2019_ENAHO_v02_M_v02_A_SEDLAC-03_all.dta"
local base_in_7   "$path\bases\sedlac\DOM\DOM_2021_ECNFT_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_8   "$path\bases\sedlac\ECU\ECU_2021_ENEMDU_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_9   "$path\bases\sedlac\GTM\GTM_2014_ENCOVI_v02_M_v02_A_SEDLAC-03_all_ocupa.dta"
local base_in_10  "$path\bases\sedlac\HND\HND_2019_EPHPM_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_11  "$path\bases\sedlac\MEX\MEX_2018_ENIGHNS_v02_M_v02_A_SEDLAC-03_all.dta"
local base_in_12  "$path\bases\sedlac\NIC\NIC_2014_EMNV_v02_M_v02_A_SEDLAC-03_all.dta"
local base_in_13  "$path\bases\sedlac\PAN\PAN_2018_EH_v01_M_v05_A_SEDLAC-03_all.dta"
local base_in_14  "$path\bases\sedlac\PER\PER_2021_ENAHO_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_15  "$path\bases\sedlac\SLV\SLV_2021_EHPM_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_16  "$path\bases\sedlac\URY\URY_2021_ECH-S2_v01_M_v01_A_SEDLAC-03_all.dta"



* Number of countries from SEDLAC database
local t = 16
mat sedlac_obs_ai = J(16,2,.)

forvalue i = 1/`t'	{

use "`base_in_`i''", clear
di in ye "Base = `base_in_`i''"


* Argentina 2021 (2d)
if `i'==1 {
local pais = "arg"
local match = "ury"

destring isco08_2d, replace
}

* Bolivia 2021 (2d)
if `i'==2 {
local pais = "bol"
local match = "slv"

destring isco08_2d, replace
}


* Brazil 2021 (2d)
if `i'==3 {
local pais = "bra"

destring isco08_2d, replace
}


* Chile 2022 (4d)
if `i'==4 {
local pais = "chl"

replace isco08_4d = "." if  isco08_4d == "0-66"
replace isco08_4d = "." if  isco08_4d == "0-88"
replace isco08_4d = "." if  isco08_4d == "0-99"

destring isco08_4d, replace 

* Calculos a 2 dígitos
replace isco08_2d="" if isco08_2d=="0-"
destring isco08_2d, replace
summ isco* 
}


* Colombia 2019 (2d)
if `i'==5 {
local pais = "col"

destring isco08_2d, replace
}

* Costa Rica 2019 (2d)
if `i'==6 {
local pais = "cri"

destring isco08_2d, replace
}



* República Dominicana 2021 (4d)
if `i'==7 {
local pais = "dom"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Ecuador 2021 (4d)
if `i'==8 {
local pais = "ecu"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Guatemala 2014 (2d)
if `i'==9 {
replace pais=lower(pais)

local pais = "gtm"
local match = "hnd"

destring isco08_2d, replace
}



* Honduras 2019 (4d)
if `i'==10 {
local pais = "hnd"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Mexico 2018 (2d)
if `i'==11 {
local pais = "mex"

destring isco08_2d, replace
}


* Nicaragua 2014 (2d)
if `i'==12 {
local pais = "nic"
local match = "hnd"

destring isco08_2d, replace
}



* Panama 2018 (4d)
if `i'==13 {
local pais = "pan"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 

* Replace variable "sector"
replace sector = 2 if sector==3
}


* Peru 2021 (4d)
if `i'==14 {
local pais = "per"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* El Salvador 2021 (4d)
if `i'==15 {
local pais = "slv"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Uruguay 2021 (4d)
if `i'==16 {
local pais = "ury"

replace isco08_4d = "." if  isco08_4d == "0"
destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}



* Calculos para potential (AI)

if `i'==4 | `i'==7 | `i'==8 | `i'==10 | `i'==13 | `i'==14 | `i'==15 | `i'==16  {
sort isco08_4d
merge isco08_4d using "$path\bases\Processed\ILO_db.dta", force
ta _merge
keep if _merge==1 | _merge==3
drop _merge

ta potential, g(pot)
drop potential
rename pot1 potential
}



if `i'==1 | `i'==2 | `i'==9 | `i'==12  {
* Match with "`match'"
sort isco08_2d hombre 
ta pais
merge isco08_2d hombre using "$path\bases\Processed\matchISCO_`match'_SEDLAC.dta", force
ta _merge
keep if _merge==1 | _merge==3
drop _merge
*summ exp_augmen_2d
rename exp_augmen_2d potential
}


if `i'==3 | `i'==5 | `i'==6 | `i'==11  {
sort pais isco08_2d hombre
merge pais isco08_2d hombre using "$path\bases\Processed\matchISCO_ILOWB.dta", force
ta _merge
keep if _merge==1 | _merge==3
drop _merge

rename exp_augmen_2d potential
replace potential = 0 if potential==.
}








count
mat sedlac_obs_ai[`i',1]= r(N)

*count if isco08_2d!=. & ocupado==1 & edad>=15 & edad<=64 & cohh==1
*count if isco08_2d!=. & ocupado==1 & edad>=15 & edad<=64
count if potential!=. & ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat sedlac_obs_ai[`i',2]= r(N)

}

mat list sedlac_obs_ai

********* TRANSFERENCIA A XLS *********
drop _all
svmat double sedlac_obs_ai
outsheet using "$path_xls\ai_sedlac_obs.xls", replace

********* CIERRA *********
mat drop _all
clear


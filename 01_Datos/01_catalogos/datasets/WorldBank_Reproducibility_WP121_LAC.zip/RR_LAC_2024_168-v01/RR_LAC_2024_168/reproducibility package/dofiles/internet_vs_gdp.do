* Must use stcolor scheme 
*set scheme stcolor
set scheme s2color

wbopendata, country()  indicator(NY.GDP.PCAP.PP.KD; IT.NET.USER.ZS)  clear  long

*select latest
drop if ny_gdp_pcap_pp_kd==. | it_net_user_zs==.
drop if year==.
egen aux=max(year), by(countrycode)
keep if aux==year
drop if year==.
drop if year<2019
 
gen lgdp=ln(ny_gdp_pcap_pp_kd)
 
  
twoway (scatter it_net_user_zs lgdp if region!="LCN" ) (scatter it_net_user_zs lgdp if region=="LCN") (qfit it_net_user_zs lgdp ) , legend(order(1 "non-LAC" 2 "LAC" 3 "Fitted line")) xtitle("GDP per capita, USD 2017 PPP (log) (WDI, circa 2021)") ytitle("Internet Users per 100 people (ITU, circa 2021)")
*twoway (scatter it_net_user_zs lgdp if region!="LCN" ) (scatter it_net_user_zs lgdp if region=="LCN") (qfit it_net_user_zs lgdp ) , legend(order(1 "non-LAC" 2 "LAC" 3 "Fitted line") position(3)) xtitle("GDP per capita, USD 2017 PPP (log) (WDI, circa 2021)") ytitle("Internet Users per 100 people (ITU, circa 2021)")
graph export "$path\Figures\internet_GDP.jpg", as(jpg) name("Graph") quality(90) replace

  
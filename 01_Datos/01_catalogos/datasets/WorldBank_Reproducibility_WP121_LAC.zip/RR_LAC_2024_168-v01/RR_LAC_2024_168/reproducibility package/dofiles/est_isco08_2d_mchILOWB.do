*** Countries with ISCO 2d information, and matched with ILO & WB database
local base_in_1   "$path\bases\sedlac\BRA\BRA_2021_PNADC-E5_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_2   "$path\bases\sedlac\COL\COL_2019_GEIH_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_3   "$path\bases\sedlac\CRI\CRI_2019_ENAHO_v02_M_v02_A_SEDLAC-03_all.dta"
local base_in_4   "$path\bases\sedlac\MEX\MEX_2018_ENIGHNS_v02_M_v02_A_SEDLAC-03_all.dta"


* Number of countries with ISCO 2d information
local t = 4

forvalue i = 1/`t'	{

use "`base_in_`i''", clear
di in ye "Base = `base_in_`i''"


* Brazil 2021 (2d)
if `i'==1 {
local pais = "bra"

destring isco08_2d, replace
}

* Colombia 2019 (2d)
if `i'==2 {
local pais = "col"

destring isco08_2d, replace
}

* Costa Rica 2019 (2d)
if `i'==3 {
local pais = "cri"

destring isco08_2d, replace
}

* Mexico 2018 (2d)
if `i'==4 {
local pais = "mex"

destring isco08_2d, replace
}

*** GENERATE VARIABLES FOR PROFILE 
* Variable g_edad
gen g_edad = 1 if edad>=15 & edad<=24 
replace g_edad = 2 if edad>=25 & edad<=34
replace g_edad = 3 if edad>=35 & edad<=44
replace g_edad = 4 if edad>=45 & edad<=54
replace g_edad = 5 if edad>=55 & edad<=64

* Variable pobre685
sort pais ano
merge pais ano using "$path\bases\Processed\ipc_sedlac_wb.dta", force keep(ppp17 ipc_sedlac ipc17_sedlac conversion)
ta _merge
keep if _merge==3
drop _merge

gen lp_685usd = (6.85*365/12)*ppp17*(ipc_sedlac/ipc17_sedlac)*conversion

gen pobre685 = 0 if ipcf!=.
replace pobre685 = 1 if ipcf<lp_685usd

* Variable qipcf
cuantiles ipcf [w=pondera] if ipcf>=0 & cohh==1, n(5) orden_aux(id com relacion edad) g(qipcf)

* Variable informal_1
gen     informal_1 = 0 if categ_lab==1
replace informal_1 = 1 if categ_lab==2

* Variable informal_2
gen     informal_2 = 1-djubila
replace informal_2 = . if asal!=1


* Pequeña modificación dado que para calcular los shares en la base de ILO WB se contempla a los ocupados con missing en ISCO 
replace isco08_2d=999 if ocupado==1 & isco08_2d==. 



*** PROFILE (NEW)
*mat `pais'_ai = J(4,28,.)
mat `pais'_ai = J(4,38,.)


* Match with data from the same country using ILO & WB database
ta pais
sort pais isco08_2d hombre
merge pais isco08_2d hombre using "$path\bases\Processed\matchISCO_ILOWB.dta", force
ta _merge
keep if _merge==1 | _merge==3
drop _merge

local potential = "augmen automa unknown"


local i = 1
foreach pot of local potential {

replace exp_`pot'_2d = 0 if exp_`pot'_2d==.

* TOTAL
summ exp_`pot'_2d [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat `pais'_ai[`i',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ exp_`pot'_2d [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h'
mat `pais'_ai[`i',2+`h']= r(mean)*100
}


* AREA (URBANO)
forvalues u =0(1)1 {
summ exp_`pot'_2d [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u'
mat `pais'_ai[`i',4+`u']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ exp_`pot'_2d [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a'
mat `pais'_ai[`i',5+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ exp_`pot'_2d [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e'
mat `pais'_ai[`i',10+`e']= r(mean)*100
}


* POVERTY
forvalues p =0(1)1 {
summ exp_`pot'_2d [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p'
mat `pais'_ai[`i',14+`p']= r(mean)*100
}


* QUINTIL (IPCF)
forvalues q =1(1)5 {
summ exp_`pot'_2d [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q'
mat `pais'_ai[`i',15+`q']= r(mean)*100
}


* LEGAL INFORMALITY (DJUBILA)
forvalues f =0(1)1 {
summ exp_`pot'_2d [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f'
mat `pais'_ai[`i',21+`f']= r(mean)*100
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
forvalues c =0(1)1 {
summ exp_`pot'_2d [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c'
mat `pais'_ai[`i',23+`c']= r(mean)*100
}

* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
summ exp_`pot'_2d [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r'
mat `pais'_ai[`i',24+`r']= r(mean)*100
}

* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
summ exp_`pot'_2d [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'
mat `pais'_ai[`i',28+`s']= r(mean)*100
}

local i = `i'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}

* Complete row for "Missing" AI category as residual en each column
forvalues m=1(1)38{
mat `pais'_ai[4,`m']= 100 - `pais'_ai[1,`m'] - `pais'_ai[2,`m'] - `pais'_ai[3,`m']
}


* DATABASE FOR REGRESSION
rename exp_augmen_2d ai_augmen
rename exp_automa_2d ai_automa
rename exp_unknown_2d ai_unknown



keep if ai_augmen!=. & ocupado==1 & edad>=15 & edad<=64 & cohh==1

*** Generate variables
** Female
gen female = 1 - hombre

** Age groups
gen ageg10lfs = 1 if edad>=16 & edad<=24
replace ageg10lfs = 2 if edad>=25 & edad<=34
replace ageg10lfs = 3 if edad>=35 & edad<=44
replace ageg10lfs = 4 if edad>=45 & edad<=54
replace ageg10lfs = 5 if edad>=55 & edad<=64

keep if ageg10lfs!=. 
tab ageg10lfs, gen(ageg10lfs_d)

* Variable education
tab nivedu, gen(edu_)


* Variable qipcf
capture drop qipcf
cuantiles ipcf [w=pondera] if ipcf>=0 & cohh==1, n(5) orden_aux(id com relacion edad) g(qipcf)
ta qipcf, g(q_)

* Variable informal_1
capture drop informal_1
gen     informal_1 = 0 if categ_lab==1
replace informal_1 = 1 if categ_lab==2

* Variable informal_2
capture drop informal_2
gen     informal_2 = 1-djubila
*replace informal_2 = . if asal!=1
replace informal_2 = 0 if ocupado==1 & relab!=. & relab!=2 & informal_2==.

* Variable relab
ta relab, gen(relab_)

* Variable sector
forvalues s=1(1)10 {
gen s_`s'=0 if sector!=.
replace s_`s'=1 if sector==`s'
}


*keep pais ano id com pondera ai_augmen ai_automa ai_unknown ai_missing female urbano ageg10lfs_d1-ageg10lfs_d5 edu_1-edu_3 q_1-q_5 informal_2 relab_1-relab_4 s_1-s_10
keep pais ano id com pondera isco08_2d ai_augmen ai_automa ai_unknown female urbano ageg10lfs_d1-ageg10lfs_d5 edu_1-edu_3 q_1-q_5 informal_2 relab_1-relab_4 s_1-s_10

append using "$path\bases\Processed\AI_regress_LAC.dta", force
saveold "$path\bases\Processed\AI_regress_LAC.dta", replace



** CLOSE PROFILES FOR EACH COUNTRY
}

mat dir


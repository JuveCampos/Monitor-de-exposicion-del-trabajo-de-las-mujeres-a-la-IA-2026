********** MATRIZ DE DATA ******** 
mat ISCO = arg_ai_comp_isco \ bol_ai_comp_isco \ bra_ai_comp_isco \ chl_ai_comp_isco \ col_ai_comp_isco \ cri_ai_comp_isco \ dom_ai_comp_isco \ ecu_ai_comp_isco \ gtm_ai_comp_isco \ hnd_ai_comp_isco \ mex_ai_comp_isco \ nic_ai_comp_isco \ pan_ai_comp_isco \ per_ai_comp_isco \ slv_ai_comp_isco \ ury_ai_comp_isco
*mat ISCO1 = arg_ai_cpuint_isco \ bol_ai_cpuint_isco \ bra_ai_cpuint_isco \ chl_ai_cpuint_isco \ col_ai_cpuint_isco \ cri_ai_cpuint_isco \ dom_ai_cpuint_isco \ ecu_ai_cpuint_isco \ gtm_ai_cpuint_isco \ hnd_ai_cpuint_isco \ mex_ai_cpuint_isco \ nic_ai_cpuint_isco \ pan_ai_cpuint_isco \ per_ai_cpuint_isco \ slv_ai_cpuint_isco \ ury_ai_cpuint_isco

********* TRANSFERENCIA A XLS *********
drop _all
svmat double ISCO
outsheet using "$path_xls\ai_comp_byisco.xls", replace

/*
drop _all
svmat double ISCO1
outsheet using "$path_xls\ai_cpuint_byisco.xls", replace
*/
********* CIERRA *********
mat drop _all
clear

/*===============================================================================================
MASTER FILE
Buffer or Bottleneck? Generative AI, employment exposure and the digital divide in Latin America

------------------------------------------------------------------------------------------------
Authors:			Pawel Gmyrek -ILO
					Hernán Winkler - WB 
					Santiago Garganta - CEDLAS/UNLP (sgarganta@cedlas.org)

Creation Date:		November, 2023
===============================================================================================*/

version 14
drop _all

*** Main folder of the project (reproducibility package)
* Compu
*global path	"E:\BackupSanti_20_11_2023\cedlas\2023\WorldBank\ISCO_08\Reproducibility package"

* Compu FCE
*global path	"D:\BackupSanti_20_11_2023\cedlas\2023\WorldBank\ISCO_08\Reproducibility package"

* Dropbox
global path	"C:\WBG\github\RR_LAC_2024_168"

sysdir set PLUS "${path}\ado"
set varabbrev on

*** Main globals and locals
local dofiles	"$path\dofiles"
global path_piaac "$path\PIAAC"
global path_xls	"$path\xls"
global path_piaac_xls "$path_piaac\xls"

local programs "cuantiles"
foreach p of local programs	{
				run "`dofiles'\ado\\`p'.do"
				}


************************ Figure using WB data on GDP per capita (USD 2017 PPP) and internet users (ITU) *******************************
do "`dofiles'\internet_vs_gdp.do"

***************************************************** PREPARE DATABASES ***************************************************************
do "`dofiles'\prepara_base.do"

*************** AI exposure and profiles for SEDLAC countries with 4d ISCO-08 data, using ILO scores directly *************************
* For countries: chl, dom, ecu, hnd, pan, per, slv, ury
do "`dofiles'\est_isco08_4d.do"

****** AI exposure and profiles for SEDLAC countries with 2d ISCO-08 data, using 2d ILO scores indirectly (SEDLAC 4d ISCO data) ******
* For countries: arg, bol, gtm, nic
do "`dofiles'\est_isco08_2d_mchSEDLAC.do"

******** AI exposure and profiles for SEDLAC countries with 2d ISCO-08 data, using ILO & WB database of the same countries ***********
* For countries: bra, col, cri, mex
do "`dofiles'\est_isco08_2d_mchILOWB.do"

*********** Merge Country profiles and outsheet of final results************
do "`dofiles'\est_all.do"

*************** Combine AI exposure imputation + Computer and Internet at work (ONLY PIAAC DATA) ********************
do "`dofiles'\ai_piaac_only.do"

******** Merge Country profiles and final results for AI + Computer and Internet at work (ONLY PIAAC DATA) **********
do "`dofiles'\est_piaac.do"

********* Combine SEDLAC AI exposure imputation + Computer work (Compture or internet at work) - PIAAC  **********
do "`dofiles'\ai_sedlac_piaac.do"

*********** Merge Country profiles and final results for AI exposure imputation + Computer work (PIAAC)************
do "`dofiles'\est_sedlac_piaac.do"

********* Combine AI exposure imputation + Computer work (Computer and internet at work) - PIAAC (by ISCO 2d) **********
do "`dofiles'\ai_sedlac_piaac_isco2d.do"

*********** Merge Country profiles and final results for AI exposure imputation + Computer work (PIAAC) by ISCO 2d************************
do "`dofiles'\est_sedlac_piaac_isco2d.do"

********* Combine AI exposure imputation + Computer and Internet at home (SEDLAC)   **********
do "`dofiles'\ai_sedlac_compuHH.do"

*** Merge Country profiles and final results for AI exposure imputation + Computer and Internet at home (SEDLAC)***
do "`dofiles'\est_sedlac_compuHH.do"

********* Check total obs. and AI exposure obs. in each sedlac database  **********
do "`dofiles'\chk_obs.do"

****************** Regressions *******************
* Pool of countries (16)
do "`dofiles'\reg_ai_LAC.do"







use "$path_piaac\bases\piaac_all.dta", clear

* survey years
gen year_survey=2012
replace year_survey=2015 if country_code=="CHL" | country_code=="GRC" | country_code=="ISR" | country_code=="LTU"| country_code=="NZL"| country_code=="SGP"| country_code=="SVN"| country_code=="TUR" 
replace year_survey=2017 if country_code=="ECU"| country_code=="HUN"| country_code=="KAZ"| country_code=="MEX"| country_code=="PER"| country_code=="USA" 

/* Use computer at work

Question	^DoiDid you use a computer in your ^JobLastjob?
Instruction	This includes cell-phones and other hand-held electronic devices that are used to connect to the internet, check e-mails etc.
Help	By computer we mean a mainframe, desktop or laptop computer, or any other device that can be used to do such things as sending or receiving e-mail messages, processing data or text, or finding things on the internet.

 G_Q04	Yes	1	1	Valid
G_Q04	No	2	2	Valid
G_Q04	Valid skip	.V	6	Missing
G_Q04	Don't know	.D	7	Missing
G_Q04	Refused	.R	8	Missing

*/

tab g_q04

gen computer_work=.
replace computer_work=0 if g_q04==2
replace computer_work=1 if g_q04==1

sum computer_work [w=weight_piaac]


/* Use internet at work
There is no a direct question in  this regard. Hence, we use several questions to estimate use of internet at work:
These questions are for g_q04==1 (workers who did not use computer at work they neither use internet at work) 

In your ^JobLastjob, how often ^DoDid you usually …
g_q05a: use email?
1 Never
2 Less than once a month
3 Less than once a week but at least once a month
4 At least once a week but not every day
5 Every day

g_q05c: use the internet in order to better understand issues related to your work?
1 Never
2 Less than once a month
3 Less than once a week but at least once a month
4 At least once a week but not every day
5 Every day

g_q05d: conduct transactions on the internet, for example buying or selling products or services, or banking?
1 Never
2 Less than once a month
3 Less than once a week but at least once a month
4 At least once a week but not every day
5 Every day

g_q05h: participate in real-time discussions on the internet, for example online conferences, or chat groups?
1 Never
2 Less than once a month
3 Less than once a week but at least once a month
4 At least once a week but not every day
5 Every day

*/
tab g_q04 if g_q05a!=.
tab g_q05a

gen internet_work=.
replace internet_work=0 if g_q04==2
replace internet_work=1 if g_q04==1
replace internet_work=0 if g_q04==1 & (g_q05a==1 & g_q05c==1 & g_q05d==1 & g_q05h==1)
 
sum internet_work [w=weight_piaac]
ta computer_work internet_work

/*
gen cpu_int_work = 1 if  computer_work==1 & internet_work==1
replace cpu_int_work = 0 if  computer_work==0 | internet_work==0
*/


/* Variable ISCO 4d
isco08_c: current job
isco08_c: last job

*/
gen isco08_4d = isco08_c
replace isco08_4d = . if isco08_c==9999
replace isco08_4d = . if isco08_c>=2 & isco08_c<=962
replace isco08_4d = . if isco08_c==2343 | isco08_c==2357 | isco08_c==2443 | isco08_c==4712 | isco08_c==5232 | isco08_c==5232 
replace isco08_4d = isco08_l if isco08_4d==. & isco08_l!=9996

keep if isco08_4d!=. 


* normalize weights by country_code
egen aux=sum(weight_piaac), by(country_code)
gen weight_piaac_relative=weight_piaac*100/aux
drop aux

* Gender
gen hombre = 1-female

* Age
tab ageg10lfs, gen(ageg10lfs_d)
gen g_edad=ageg10lfs

* Education
/*
educ_level:
1. less than highschool
2. highschool
3. above highschool
*/
gen nivedu=educ_level


* Imputation of ILO AI exposure scores
sort isco08_4d
merge isco08_4d using "$path\bases\Processed\ILO_db.dta", force
ta _merge
keep if _merge==1 | _merge==3
drop _merge

ta potential, g(pot)
rename pot1 pot_augmen
rename pot2 pot_automa
rename pot3 pot_unknown
rename pot4 pot_missing


gen ncomputer_work=1-computer_work
gen ninternet_work=1-internet_work

** Generate variables to estimate probabilities
/* Computer and internet at work
Pr(Augmentation=1, Computer at work=1)
Pr(Augmentation=1, Computer at work=0)
Pr(Automation=1, Computer at work=1)
Pr(Automation=1, Computer at work=0)
Pr(Big Unknown=1, Computer at work=1)
Pr(Big Unknown=1, Computer at work=0)
Pr(Missing=1, Computer at work=1)
Pr(Missing=1, Computer at work=0)
*/
gen augmen_compu=pot_augmen*computer_work
gen augmen_ncompu=pot_augmen*ncomputer_work
gen automa_compu=pot_automa*computer_work
gen automa_ncompu=pot_automa*ncomputer_work
gen unknown_compu=pot_unknown*computer_work
gen unknown_ncompu=pot_unknown*ncomputer_work
gen missing_compu=pot_missing*computer_work
gen missing_ncompu=pot_missing*ncomputer_work


/* Computer and internet at work
Pr(Augmentation=1, Computer & internet at work=1)
Pr(Augmentation=1, Computer & internet at work=0)
Pr(Automation=1, Computer & internet at work=1)
Pr(Automation=1, Computer & internet at work=0)
Pr(Big Unknown=1, Computer & internet at work=1)
Pr(Big Unknown=1, Computer & internet at work=0)
Pr(Missing=1, Computer & internet at work=1)
Pr(Missing=1, Computer & internet at work=0)
*/
gen augmen_int=pot_augmen*internet_work
gen augmen_nint=pot_augmen*ninternet_work
gen automa_int=pot_automa*internet_work
gen automa_nint=pot_automa*ninternet_work
gen unknown_int=pot_unknown*internet_work
gen unknown_nint=pot_unknown*ninternet_work
gen missing_int=pot_missing*internet_work
gen missing_nint=pot_missing*ninternet_work


/* variables "pais_"
pais_*==1
*:
1	BEL  
2	CHL
3	CZE
4	DNK
5	ECU
6	ESP
7	FRA
8	GBR
9	GRC
10	HUN
11	ISR
12	ITA
13	JPN
14	KAZ
15	KOR
16	LTU
17	MEX
18	NLD
19	NZL
20	PER
21	POL
22	RUS
23	SVK
24	SVN
25	TUR
*/
ta country_code, gen(pais_)


forvalues p = 1/25	{

* Locals for each country
if `p'==1 {
local pais = "bel"
}
if `p'==2 {
local pais = "chl"
}
if `p'==3 {
local pais = "cze"
}
if `p'==4 {
local pais = "dnk"
}
if `p'==5 {
local pais = "ecu"
}
if `p'==6 {
local pais = "esp"
}
if `p'==7 {
local pais = "fra"
}
if `p'==8 {
local pais = "gbr"
}
if `p'==9 {
local pais = "grc"
}
if `p'==10 {
local pais = "hun"
}
if `p'==11 {
local pais = "isr"
}
if `p'==12 {
local pais = "ita"
}
if `p'==13 {
local pais = "jpn"
}
if `p'==14 {
local pais = "kaz"
}
if `p'==15 {
local pais = "kor"
}
if `p'==16 {
local pais = "ltu"
}
if `p'==17 {
local pais = "mex"
}
if `p'==18 {
local pais = "nld"
}
if `p'==19 {
local pais = "nzl"
}
if `p'==20 {
local pais = "per"
}
if `p'==21 {
local pais = "pol"
}
if `p'==22 {
local pais = "rus"
}
if `p'==23 {
local pais = "svk"
}
if `p'==24 {
local pais = "svn"
}
if `p'==25 {
local pais = "tur"
}


*** PROFILE FOR AI & COMPUTER AT WORK
local potential = "augmen_compu augmen_ncompu automa_compu automa_ncompu unknown_compu unknown_ncompu missing_compu missing_ncompu"
mat `pais'_ai_cpu = J(8,11,.)

local cat = 1
foreach pot of local potential {

* TOTAL
summ `pot' [w=weight_piaac_relative] if pais_`p'==1 
mat `pais'_ai_cpu[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=weight_piaac_relative] if pais_`p'==1 & hombre==`h'
mat `pais'_ai_cpu[`cat',2+`h']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=weight_piaac_relative] if pais_`p'==1 & g_edad==`a'
mat `pais'_ai_cpu[`cat',3+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=weight_piaac_relative] if pais_`p'==1 & nivedu==`e'
mat `pais'_ai_cpu[`cat',8+`e']= r(mean)*100
}

local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}


*** PROFILE FOR AI & COMPUTER AND INTERNET AT WORK
local potential = "augmen_int augmen_nint automa_int automa_nint unknown_int unknown_nint missing_int missing_nint"
mat `pais'_ai_int = J(8,11,.)

local cat = 1
foreach pot of local potential {

* TOTAL
summ `pot' [w=weight_piaac_relative] if pais_`p'==1 
mat `pais'_ai_int[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=weight_piaac_relative] if pais_`p'==1 & hombre==`h'
mat `pais'_ai_int[`cat',2+`h']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=weight_piaac_relative] if pais_`p'==1 & g_edad==`a'
mat `pais'_ai_int[`cat',3+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=weight_piaac_relative] if pais_`p'==1 & nivedu==`e'
mat `pais'_ai_int[`cat',8+`e']= r(mean)*100
}

local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}




** CLOSE COUNTRY
}

mat dir

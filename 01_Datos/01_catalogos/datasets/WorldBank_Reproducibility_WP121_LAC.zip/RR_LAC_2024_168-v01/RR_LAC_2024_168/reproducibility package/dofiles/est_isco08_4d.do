*** Countries with ISCO 4d information
local base_in_1   "$path\bases\sedlac\CHL\CHL_2022_CASEN_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_2   "$path\bases\sedlac\DOM\DOM_2021_ECNFT_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_3   "$path\bases\sedlac\ECU\ECU_2021_ENEMDU_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_4   "$path\bases\sedlac\HND\HND_2019_EPHPM_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_5   "$path\bases\sedlac\PAN\PAN_2018_EH_v01_M_v05_A_SEDLAC-03_all.dta"
local base_in_6   "$path\bases\sedlac\PER\PER_2021_ENAHO_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_7   "$path\bases\sedlac\SLV\SLV_2021_EHPM_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_8   "$path\bases\sedlac\URY\URY_2021_ECH-S2_v01_M_v01_A_SEDLAC-03_all.dta"



* Number of countries with ISCO 4d information
local t = 8


forvalue i = 1/`t'	{

use "`base_in_`i''", clear
di in ye "Base = `base_in_`i''"

* Chile 2022 (4d)
if `i'==1 {
local pais = "chl"

replace isco08_4d = "." if  isco08_4d == "0-66"
replace isco08_4d = "." if  isco08_4d == "0-88"
replace isco08_4d = "." if  isco08_4d == "0-99"

destring isco08_4d, replace 

* Calculos a 2 dígitos
replace isco08_2d="" if isco08_2d=="0-"
destring isco08_2d, replace
summ isco* 
}


* República Dominicana 2021 (4d)
if `i'==2 {
local pais = "dom"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Ecuador 2021 (4d)
if `i'==3 {
local pais = "ecu"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Honduras 2019 (4d)
if `i'==4 {
local pais = "hnd"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Panama 2018 (4d)
if `i'==5 {
local pais = "pan"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 

* Replace variable "sector"
replace sector = 2 if sector==3
}


* Peru 2021 (4d)
if `i'==6 {
local pais = "per"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* El Salvador 2021 (4d)
if `i'==7 {
local pais = "slv"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Uruguay 2021 (4d)
if `i'==8 {
local pais = "ury"

replace isco08_4d = "." if  isco08_4d == "0"
destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}




* Calculos para potential (AI)
sort isco08_4d
merge isco08_4d using "$path\bases\Processed\ILO_db.dta", force
ta _merge
keep if _merge==1 | _merge==3
drop _merge


ta potential, g(pot)


*** PROFILE 
*mat `pais'_ai = J(4,28,.)
mat `pais'_ai = J(4,38,.)

* TOTAL
ta potential [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1, matcell(aux)
forvalues i=1(1)4 {
mat `pais'_ai[`i',1] = (aux[`i',1]/(aux[1,1]+aux[2,1]+aux[3,1]+aux[4,1]))*100
}
mat drop aux


* GENDER (HOMBRE)
forvalues h =0(1)1 {
	ta potential [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h', matcell(aux)

	forvalues i=1(1)4 {
		mat `pais'_ai[`i',2+`h'] = (aux[`i',1]/(aux[1,1]+aux[2,1]+aux[3,1]+aux[4,1]))*100
	}
	mat drop aux
}


* AREA (URBANO)
forvalues u =0(1)1 {
	ta potential [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u', matcell(aux)

	forvalues i=1(1)4 {
		mat `pais'_ai[`i',4+`u'] = (aux[`i',1]/(aux[1,1]+aux[2,1]+aux[3,1]+aux[4,1]))*100
	}
	mat drop aux
}


* AGE (G_EDAD)
gen g_edad = 1 if edad>=15 & edad<=24 
replace g_edad = 2 if edad>=25 & edad<=34
replace g_edad = 3 if edad>=35 & edad<=44
replace g_edad = 4 if edad>=45 & edad<=54
replace g_edad = 5 if edad>=55 & edad<=64

forvalues a =1(1)5 {
	ta potential [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a', matcell(aux)

	forvalues i=1(1)4 {
		mat `pais'_ai[`i',5+`a'] = (aux[`i',1]/(aux[1,1]+aux[2,1]+aux[3,1]+aux[4,1]))*100
	}
	mat drop aux
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
	ta potential [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e', matcell(aux)

	forvalues i=1(1)4 {
		mat `pais'_ai[`i',10+`e'] = (aux[`i',1]/(aux[1,1]+aux[2,1]+aux[3,1]+aux[4,1]))*100
	}
	mat drop aux
}


* POVERTY
sort pais ano
merge pais ano using "$path\bases\Processed\ipc_sedlac_wb.dta", force keep(ppp17 ipc_sedlac ipc17_sedlac conversion)
ta _merge
keep if _merge==3
drop _merge

gen lp_685usd = (6.85*365/12)*ppp17*(ipc_sedlac/ipc17_sedlac)*conversion

gen pobre685 = 0 if ipcf!=.
replace pobre685 = 1 if ipcf<lp_685usd

forvalues p =0(1)1 {
	ta potential [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p', matcell(aux)

	forvalues i=1(1)4 {
		mat `pais'_ai[`i',14+`p'] = (aux[`i',1]/(aux[1,1]+aux[2,1]+aux[3,1]+aux[4,1]))*100
	}
	mat drop aux
}


* QUINTIL (IPCF)
cuantiles ipcf [w=pondera] if ipcf>=0 & cohh==1, n(5) orden_aux(id com relacion edad) g(qipcf)

forvalues q =1(1)5 {
	ta potential [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q', matcell(aux)

	forvalues i=1(1)4 {
		mat `pais'_ai[`i',15+`q'] = (aux[`i',1]/(aux[1,1]+aux[2,1]+aux[3,1]+aux[4,1]))*100
	}
	mat drop aux
}


* LEGAL INFORMALITY (DJUBILA)
gen     informal_2 = 1-djubila
replace informal_2 = . if asal!=1

forvalues f =0(1)1 {
	ta potential [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f', matcell(aux)

	forvalues i=1(1)4 {
		mat `pais'_ai[`i',21+`f'] = (aux[`i',1]/(aux[1,1]+aux[2,1]+aux[3,1]+aux[4,1]))*100
	}
	mat drop aux
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
gen     informal_1 = 0 if categ_lab==1
replace informal_1 = 1 if categ_lab==2

forvalues c =0(1)1 {
	ta potential [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c', matcell(aux)

	forvalues i=1(1)4 {
		mat `pais'_ai[`i',23+`c'] = (aux[`i',1]/(aux[1,1]+aux[2,1]+aux[3,1]+aux[4,1]))*100
	}
	mat drop aux
}


* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
	ta potential [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r', matcell(aux)

	forvalues i=1(1)4 {
		mat `pais'_ai[`i',24+`r'] = (aux[`i',1]/(aux[1,1]+aux[2,1]+aux[3,1]+aux[4,1]))*100
	}
	mat drop aux
}


* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
	ta potential [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s', matcell(aux)
	
	if r(r)==4 {
	forvalues i=1(1)4 {
		mat `pais'_ai[`i',28+`s'] = (aux[`i',1]/(aux[1,1]+aux[2,1]+aux[3,1]+aux[4,1]))*100
	}
	mat drop aux
	}
	
	if r(r)!=4 {
	forvalues i=1(1)4 {
	summ pot`i' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'	
	mat `pais'_ai[`i',28+`s'] = r(mean)*100
	}
	}

}



* DATABASE FOR REGRESSION
rename pot1 ai_augmen
rename pot2 ai_automa
rename pot3 ai_unknown
rename pot4 ai_missing

keep if ai_augmen!=. & ocupado==1 & edad>=15 & edad<=64 & cohh==1

*** Generate variables
** Female
gen female = 1 - hombre

** Age groups
gen ageg10lfs = 1 if edad>=16 & edad<=24
replace ageg10lfs = 2 if edad>=25 & edad<=34
replace ageg10lfs = 3 if edad>=35 & edad<=44
replace ageg10lfs = 4 if edad>=45 & edad<=54
replace ageg10lfs = 5 if edad>=55 & edad<=64

keep if ageg10lfs!=. 
tab ageg10lfs, gen(ageg10lfs_d)

* Variable education
tab nivedu, gen(edu_)


* Variable qipcf
capture drop qipcf
cuantiles ipcf [w=pondera] if ipcf>=0 & cohh==1, n(5) orden_aux(id com relacion edad) g(qipcf)
ta qipcf, g(q_)

* Variable informal_1
capture drop informal_1
gen     informal_1 = 0 if categ_lab==1
replace informal_1 = 1 if categ_lab==2

* Variable informal_2
capture drop informal_2
gen     informal_2 = 1-djubila
*replace informal_2 = . if asal!=1
replace informal_2 = 0 if ocupado==1 & relab!=. & relab!=2 & informal_2==.

* Variable relab
ta relab, gen(relab_)

* Variable sector
forvalues s=1(1)10 {
gen s_`s'=0 if sector!=.
replace s_`s'=1 if sector==`s'
}


keep pais ano id com pondera isco08_2d isco08_4d ai_augmen ai_automa ai_unknown female urbano ageg10lfs_d1-ageg10lfs_d5 edu_1-edu_3 q_1-q_5 informal_2 relab_1-relab_4 s_1-s_10
tempfile new
save `new', replace


if "`pais'"!="chl" {
append using "$path\bases\Processed\AI_LAC_4d.dta", force
}

saveold "$path\bases\Processed\AI_LAC_4d.dta", replace


** DATA for Regress
use `new', clear

*keep pais ano id com pondera ai_augmen ai_automa ai_unknown ai_missing female urbano ageg10lfs_d1-ageg10lfs_d5 edu_1-edu_3 q_1-q_5 informal_2 relab_1-relab_4 s_1-s_10
keep pais ano id com pondera isco08_2d ai_augmen ai_automa ai_unknown female urbano ageg10lfs_d1-ageg10lfs_d5 edu_1-edu_3 q_1-q_5 informal_2 relab_1-relab_4 s_1-s_10


if "`pais'"!="chl" {
append using "$path\bases\Processed\AI_regress_LAC.dta", force
}

saveold "$path\bases\Processed\AI_regress_LAC.dta", replace



** CLOSE PROFILES
}

*mat list `pais'_ai
mat dir















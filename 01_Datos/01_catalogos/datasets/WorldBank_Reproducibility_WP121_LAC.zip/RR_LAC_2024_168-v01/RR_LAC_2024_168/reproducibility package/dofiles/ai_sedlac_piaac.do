use "$path_piaac\bases\piaac_all.dta", clear

* survey years
gen year_survey=2012
replace year_survey=2015 if country_code=="CHL" | country_code=="GRC" | country_code=="ISR" | country_code=="LTU"| country_code=="NZL"| country_code=="SGP"| country_code=="SVN"| country_code=="TUR" 
replace year_survey=2017 if country_code=="ECU"| country_code=="HUN"| country_code=="KAZ"| country_code=="MEX"| country_code=="PER"| country_code=="USA" 

/* Use computer at work

Question	^DoiDid you use a computer in your ^JobLastjob?
Instruction	This includes cell-phones and other hand-held electronic devices that are used to connect to the internet, check e-mails etc.
Help	By computer we mean a mainframe, desktop or laptop computer, or any other device that can be used to do such things as sending or receiving e-mail messages, processing data or text, or finding things on the internet.

 G_Q04	Yes	1	1	Valid
G_Q04	No	2	2	Valid
G_Q04	Valid skip	.V	6	Missing
G_Q04	Don't know	.D	7	Missing
G_Q04	Refused	.R	8	Missing

*/

tab g_q04

gen computer_work=.
replace computer_work=0 if g_q04==2
replace computer_work=1 if g_q04==1

sum computer_work [w=weight_piaac]


/* Use internet at work
There is no a direct question in  this regard. Hence, we use several questions to estimate use of internet at work:
These questions are for g_q04==1 (workers who did not use computer at work they neither use internet at work) 

In your ^JobLastjob, how often ^DoDid you usually …
g_q05a: use email?
1 Never
2 Less than once a month
3 Less than once a week but at least once a month
4 At least once a week but not every day
5 Every day

g_q05c: use the internet in order to better understand issues related to your work?
1 Never
2 Less than once a month
3 Less than once a week but at least once a month
4 At least once a week but not every day
5 Every day

g_q05d: conduct transactions on the internet, for example buying or selling products or services, or banking?
1 Never
2 Less than once a month
3 Less than once a week but at least once a month
4 At least once a week but not every day
5 Every day

g_q05h: participate in real-time discussions on the internet, for example online conferences, or chat groups?
1 Never
2 Less than once a month
3 Less than once a week but at least once a month
4 At least once a week but not every day
5 Every day

*/
tab g_q04 if g_q05a!=.
tab g_q05a

gen internet_work=.
replace internet_work=0 if g_q04==2
replace internet_work=1 if g_q04==1
replace internet_work=0 if g_q04==1 & (g_q05a==1 & g_q05c==1 & g_q05d==1 & g_q05h==1)
 
sum internet_work [w=weight_piaac]
ta computer_work internet_work

/*
gen cpu_int_work = 1 if  computer_work==1 & internet_work==1
replace cpu_int_work = 0 if  computer_work==0 | internet_work==0
*/



preserve
collapse (mean) computer_work internet_work [w=weight_piaac], by(country_code year_survey)

tempfile comp_piaac
save `comp_piaac', replace
restore

* get WDI indicators 
*	Individuals using the Internet (% of population) (IT.NET.USER.ZS)
* 	GDP per capita, PPP (constant 2017 international $) (NY.GDP.PCAP.PP.KD)
*Fixed broadband subscriptions (per 100 people) (IT.NET.BBND.P2)


wbopendata, indicators(IT.NET.BBND.P2; IT.NET.USER.ZS; NY.GDP.PCAP.PP.KD) clear long

keep countrycode countryname year it* ny*
rename  countrycode country_code
rename year year_survey
merge 1:1 country_code year using `comp_piaac'
keep if _merge==3

gen log_gdp=ln(ny)

rename it_net_bbnd_p2 broadband_rate
rename it_net_user_zs internet_users_rate

foreach var in broadband_rate internet_users_rate {
	replace `var'=`var'/100
	
}
/*
twoway (scatter computer_work log_gdp, mlabel(countryname))
twoway (scatter computer_work internet_users_rate , mlabel(countryname))
twoway (scatter computer_work broadband_rate, mlabel(countryname))

twoway (scatter internet_work log_gdp, mlabel(countryname))
twoway (scatter internet_work internet_users_rate , mlabel(countryname))
twoway (scatter internet_work broadband_rate, mlabel(countryname))
*/ 
reg computer_work  log_gdp internet_users_rate broadband_rate i.year
reg internet_work  log_gdp internet_users_rate broadband_rate i.year


drop _merge computer_work internet_work
tempfile wdi
save `wdi', replace


* join WDI aggregates to clean PIAAC
use "$path_piaac\bases\piaac_all.dta", clear

/* Use computer at work
Question	^DoiDid you use a computer in your ^JobLastjob?
Instruction	This includes cell-phones and other hand-held electronic devices that are used to connect to the internet, check e-mails etc.
Help	By computer we mean a mainframe, desktop or laptop computer, or any other device that can be used to do such things as sending or receiving e-mail messages, processing data or text, or finding things on the internet.

 G_Q04	Yes	1	1	Valid
G_Q04	No	2	2	Valid
G_Q04	Valid skip	.V	6	Missing
G_Q04	Don't know	.D	7	Missing
G_Q04	Refused	.R	8	Missing

*/

merge m:1 country_code using `wdi'
drop _merge

tab g_q04

gen computer_work=.
replace computer_work=0 if g_q04==2
replace computer_work=1 if g_q04==1

sum computer_work [w=weight_piaac]


/* Use internet at work
There is no a direct question in  this regard. Hence, we use several questions to estimate use of internet at work:
These questions are for g_q04==1 (workers who did not use computer at work they neither use internet at work) 

In your ^JobLastjob, how often ^DoDid you usually …
g_q05a: use email?
1 Never
2 Less than once a month
3 Less than once a week but at least once a month
4 At least once a week but not every day
5 Every day

g_q05c: use the internet in order to better understand issues related to your work?
1 Never
2 Less than once a month
3 Less than once a week but at least once a month
4 At least once a week but not every day
5 Every day

g_q05d: conduct transactions on the internet, for example buying or selling products or services, or banking?
1 Never
2 Less than once a month
3 Less than once a week but at least once a month
4 At least once a week but not every day
5 Every day

g_q05h: participate in real-time discussions on the internet, for example online conferences, or chat groups?
1 Never
2 Less than once a month
3 Less than once a week but at least once a month
4 At least once a week but not every day
5 Every day

*/
tab g_q04 if g_q05a!=.
tab g_q05a

gen internet_work=.
replace internet_work=0 if g_q04==2
replace internet_work=1 if g_q04==1
replace internet_work=0 if g_q04==1 & (g_q05a==1 & g_q05c==1 & g_q05d==1 & g_q05h==1)


gen isco_2d=floor(isco08_c/100)
replace isco_2d=. if isco_2d<11 | isco_2d>=99 
replace isco_2d=isco2c if isco_2d==. & isco2c>=11 & isco2c<=96

keep if isco_2d!=. 

* normalize weights by country_code
egen aux=sum(weight_piaac), by(country_code)
gen weight_piaac_relative=weight_piaac*100/aux
drop aux

* only one obs for isco=47,
drop if isco_2d==47

tab ageg10lfs, gen(ageg10lfs_d)


tab isco_2d, gen(isco_2d_d)

foreach var in  isco_2d_d1 isco_2d_d2 isco_2d_d3 isco_2d_d4 isco_2d_d5 isco_2d_d6 isco_2d_d7 isco_2d_d8 isco_2d_d9 isco_2d_d10 isco_2d_d11 isco_2d_d12 isco_2d_d13 isco_2d_d14 isco_2d_d15 isco_2d_d16 isco_2d_d17 isco_2d_d18 isco_2d_d19 isco_2d_d20 isco_2d_d21 isco_2d_d22 isco_2d_d23 isco_2d_d24 isco_2d_d25 isco_2d_d26 isco_2d_d27 isco_2d_d28 isco_2d_d29 isco_2d_d30 isco_2d_d31 isco_2d_d32 isco_2d_d33 isco_2d_d34 isco_2d_d35 isco_2d_d36 isco_2d_d37 isco_2d_d38 isco_2d_d39 isco_2d_d40  {
	
	sum isco_2d if `var'==1
	local mean=r(mean)
	gen isco_2d_c`mean'=`var'
	drop `var'
}

* Coef. Computer at work
logit computer_work isco_2d_c12 isco_2d_c13 isco_2d_c14 isco_2d_c21 isco_2d_c22 isco_2d_c23 isco_2d_c24 isco_2d_c25 isco_2d_c26 isco_2d_c31 isco_2d_c32 isco_2d_c33 isco_2d_c34 isco_2d_c35 isco_2d_c41 isco_2d_c42 isco_2d_c43 isco_2d_c44 isco_2d_c51 isco_2d_c52 isco_2d_c53 isco_2d_c54 isco_2d_c61 isco_2d_c62 isco_2d_c63 isco_2d_c71 isco_2d_c72 isco_2d_c73 isco_2d_c74 isco_2d_c75 isco_2d_c81 isco_2d_c82 isco_2d_c83 isco_2d_c91 isco_2d_c92 isco_2d_c93 isco_2d_c94 isco_2d_c95 isco_2d_c96 [pw=weight_piaac_relative]
logit computer_work isco_2d_c12 isco_2d_c13 isco_2d_c14 isco_2d_c21 isco_2d_c22 isco_2d_c23 isco_2d_c24 isco_2d_c25 isco_2d_c26 isco_2d_c31 isco_2d_c32 isco_2d_c33 isco_2d_c34 isco_2d_c35 isco_2d_c41 isco_2d_c42 isco_2d_c43 isco_2d_c44 isco_2d_c51 isco_2d_c52 isco_2d_c53 isco_2d_c54 isco_2d_c61 isco_2d_c62 isco_2d_c63 isco_2d_c71 isco_2d_c72 isco_2d_c73 isco_2d_c74 isco_2d_c75 isco_2d_c81 isco_2d_c82 isco_2d_c83 isco_2d_c91 isco_2d_c92 isco_2d_c93 isco_2d_c94 isco_2d_c95 isco_2d_c96 log_gdp internet_users_rate broadband_rate [pw=weight_piaac_relative]
logit computer_work isco_2d_c12 isco_2d_c13 isco_2d_c14 isco_2d_c21 isco_2d_c22 isco_2d_c23 isco_2d_c24 isco_2d_c25 isco_2d_c26 isco_2d_c31 isco_2d_c32 isco_2d_c33 isco_2d_c34 isco_2d_c35 isco_2d_c41 isco_2d_c42 isco_2d_c43 isco_2d_c44 isco_2d_c51 isco_2d_c52 isco_2d_c53 isco_2d_c54 isco_2d_c61 isco_2d_c62 isco_2d_c63 isco_2d_c71 isco_2d_c72 isco_2d_c73 isco_2d_c74 isco_2d_c75 isco_2d_c81 isco_2d_c82 isco_2d_c83 isco_2d_c91 isco_2d_c92 isco_2d_c93 isco_2d_c94 isco_2d_c95 isco_2d_c96 ageg10lfs_d2-ageg10lfs_d5 female high_educ log_gdp internet_users_rate broadband_rate [pw=weight_piaac_relative]
outreg2 using "$path_piaac_xls\cpu_int_work_regress.xls", replace 
predict computer_work_hat

* NEW (begin)
local cte = _b[_cons]
mat coef_aux=e(b)
mat coef_logit= coef_aux[1,1..48]
mat drop coef_aux
* NEW (end)


* Coef. Computer and internet at work
logit internet_work isco_2d_c12 isco_2d_c13 isco_2d_c14 isco_2d_c21 isco_2d_c22 isco_2d_c23 isco_2d_c24 isco_2d_c25 isco_2d_c26 isco_2d_c31 isco_2d_c32 isco_2d_c33 isco_2d_c34 isco_2d_c35 isco_2d_c41 isco_2d_c42 isco_2d_c43 isco_2d_c44 isco_2d_c51 isco_2d_c52 isco_2d_c53 isco_2d_c54 isco_2d_c61 isco_2d_c62 isco_2d_c63 isco_2d_c71 isco_2d_c72 isco_2d_c73 isco_2d_c74 isco_2d_c75 isco_2d_c81 isco_2d_c82 isco_2d_c83 isco_2d_c91 isco_2d_c92 isco_2d_c93 isco_2d_c94 isco_2d_c95 isco_2d_c96 [pw=weight_piaac_relative]
logit internet_work isco_2d_c12 isco_2d_c13 isco_2d_c14 isco_2d_c21 isco_2d_c22 isco_2d_c23 isco_2d_c24 isco_2d_c25 isco_2d_c26 isco_2d_c31 isco_2d_c32 isco_2d_c33 isco_2d_c34 isco_2d_c35 isco_2d_c41 isco_2d_c42 isco_2d_c43 isco_2d_c44 isco_2d_c51 isco_2d_c52 isco_2d_c53 isco_2d_c54 isco_2d_c61 isco_2d_c62 isco_2d_c63 isco_2d_c71 isco_2d_c72 isco_2d_c73 isco_2d_c74 isco_2d_c75 isco_2d_c81 isco_2d_c82 isco_2d_c83 isco_2d_c91 isco_2d_c92 isco_2d_c93 isco_2d_c94 isco_2d_c95 isco_2d_c96 log_gdp internet_users_rate broadband_rate [pw=weight_piaac_relative]
logit internet_work isco_2d_c12 isco_2d_c13 isco_2d_c14 isco_2d_c21 isco_2d_c22 isco_2d_c23 isco_2d_c24 isco_2d_c25 isco_2d_c26 isco_2d_c31 isco_2d_c32 isco_2d_c33 isco_2d_c34 isco_2d_c35 isco_2d_c41 isco_2d_c42 isco_2d_c43 isco_2d_c44 isco_2d_c51 isco_2d_c52 isco_2d_c53 isco_2d_c54 isco_2d_c61 isco_2d_c62 isco_2d_c63 isco_2d_c71 isco_2d_c72 isco_2d_c73 isco_2d_c74 isco_2d_c75 isco_2d_c81 isco_2d_c82 isco_2d_c83 isco_2d_c91 isco_2d_c92 isco_2d_c93 isco_2d_c94 isco_2d_c95 isco_2d_c96 ageg10lfs_d2-ageg10lfs_d5 female high_educ log_gdp internet_users_rate broadband_rate [pw=weight_piaac_relative]
outreg2 using "$path_piaac_xls\cpu_int_work_regress.xls", append
predict internet_work_hat

* NEW (begin)
local cte_int = _b[_cons]
mat coef_aux=e(b)
mat coef_logit_int= coef_aux[1,1..48]
mat drop coef_aux	
* NEW (end)



clear

******** Predict "computer & internet use at work" using SEDLAC database with piaac coeff **********
local base_in_1   "$path\bases\sedlac\ARG\ARG_2021_EPHC-S2_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_2   "$path\bases\sedlac\BOL\BOL_2021_EH_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_3   "$path\bases\sedlac\BRA\BRA_2021_PNADC-E5_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_4   "$path\bases\sedlac\CHL\CHL_2022_CASEN_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_5   "$path\bases\sedlac\COL\COL_2019_GEIH_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_6   "$path\bases\sedlac\CRI\CRI_2019_ENAHO_v02_M_v02_A_SEDLAC-03_all.dta"
local base_in_7   "$path\bases\sedlac\DOM\DOM_2021_ECNFT_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_8   "$path\bases\sedlac\ECU\ECU_2021_ENEMDU_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_9   "$path\bases\sedlac\GTM\GTM_2014_ENCOVI_v02_M_v02_A_SEDLAC-03_all_ocupa.dta"
local base_in_10   "$path\bases\sedlac\HND\HND_2019_EPHPM_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_11   "$path\bases\sedlac\MEX\MEX_2018_ENIGHNS_v02_M_v02_A_SEDLAC-03_all.dta"
local base_in_12   "$path\bases\sedlac\NIC\NIC_2014_EMNV_v02_M_v02_A_SEDLAC-03_all.dta"
local base_in_13   "$path\bases\sedlac\PAN\PAN_2018_EH_v01_M_v05_A_SEDLAC-03_all.dta"
local base_in_14   "$path\bases\sedlac\PER\PER_2021_ENAHO_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_15   "$path\bases\sedlac\SLV\SLV_2021_EHPM_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_16   "$path\bases\sedlac\URY\URY_2021_ECH-S2_v01_M_v01_A_SEDLAC-03_all.dta"


** Get WDI indicators for SEDLAC databases 
/*
Individuals using the Internet (% of population) (IT.NET.USER.ZS)
GDP per capita, PPP (constant 2017 international $) (NY.GDP.PCAP.PP.KD)
Fixed broadband subscriptions (per 100 people) (IT.NET.BBND.P2)
*/

wbopendata, indicators(IT.NET.BBND.P2; IT.NET.USER.ZS; NY.GDP.PCAP.PP.KD) clear long
keep countrycode countryname year it* ny*

* We keep LAC countries and the corresponding year of SEDLAC survey in each case
keep if (countrycode=="ARG" & year==2021) | (countrycode=="BOL" & year==2021) | (countrycode=="BRA" & year==2021) |            ///
(countrycode=="CHL" & (year==2021 | year==2022) ) | (countrycode=="COL" & year==2019) | (countrycode=="CRI" & year==2019) |    ///  
(countrycode=="DOM" & year==2021) | (countrycode=="ECU" & year==2021) | (countrycode=="GTM" & year==2014) |                    ///
(countrycode=="HND" & year==2019) | (countrycode=="MEX" & year==2018) | (countrycode=="NIC" & year==2014) |                    ///
(countrycode=="PAN" & year==2018) | (countrycode=="PER" & year==2021) | (countrycode=="SLV" & year==2021) |                    ///
(countrycode=="URY" & year==2021)

* Variable it_net_user_zs is missing for CHL 2022, hence we use value of 2021 for this variable and country
sort countrycode year
replace it_net_user_zs=it_net_user_zs[_n-1] if it_net_user_zs==. 
drop if countrycode=="CHL" & year==2021

gen log_gdp=ln(ny)

rename it_net_bbnd_p2 broadband_rate
rename it_net_user_zs internet_users_rate

foreach var in broadband_rate internet_users_rate {
	replace `var'=`var'/100
	
}
keep countrycode year log_gdp broadband_rate internet_users_rate
gen pais = lower(countrycode)
drop countrycode
order pais
rename year ano

tempfile wdi_sedlac
sort pais ano
save `wdi_sedlac', replace



* Number of countries from SEDLAC database
local t = 16


forvalue i = 1/`t'	{

use "`base_in_`i''", clear
di in ye "Base = `base_in_`i''"

replace pais=lower(pais)

*** Generate variables to predict "computer use at work"
** Country-level variables (from WB database)
sort pais ano
merge pais ano using `wdi_sedlac'
ta _merge
keep if _merge==3
drop _merge


** Female
gen female = 1 - hombre

** Age groups
gen ageg10lfs = 1 if edad>=16 & edad<=24
replace ageg10lfs = 2 if edad>=25 & edad<=34
replace ageg10lfs = 3 if edad>=35 & edad<=44
replace ageg10lfs = 4 if edad>=45 & edad<=54
replace ageg10lfs = 5 if edad>=55 & edad<=64

keep if ageg10lfs!=. 
tab ageg10lfs, gen(ageg10lfs_d)

** Education
gen high_educ = 0 if nivel!=.
replace high_educ = 1 if nivel==5 | nivel==6


** Calculate ISCO 2d
* BOLIVIA
if `i'==2 {
destring isco08_2d, replace
drop if isco08_2d == 16
drop if isco08_2d == 55
drop if isco08_2d == 85
drop if isco08_2d == 88
}

* CHILE
if `i'==4 {
replace isco08_2d="" if isco08_2d=="0-"
destring isco08_2d, replace
drop if isco08_2d == 36
}

* URUGUAY
if `i'==16 {
destring isco08_2d, replace
drop if isco08_2d == 49
drop if isco08_2d == 56
drop if isco08_2d == 64
}



destring isco08_2d, replace
rename isco08_2d isco_2d
keep if isco_2d!=. 
* We restrict to isco2d codes in PIAAC database
keep if isco_2d>=11 & isco_2d<=96
 

tab isco_2d, gen(isco_2d_d)
local isco_tot=r(r)

forvalues o=1(1)`isco_tot' {
sum isco_2d if isco_2d_d`o'==1
local mean=r(mean)
gen isco_2d_c`mean'=isco_2d_d`o'
drop isco_2d_d`o'
}

** Genero variables ISCO=0 para los códigos que no existen en cada país 
* ARGENTINA
if `i'==1 {
local pais="arg"
gen isco_2d_c12 = 0
gen isco_2d_c63 = 0
}

* BOLIVIA
if `i'==2 {
local pais="bol"
gen isco_2d_c63 = 0
gen isco_2d_c82 = 0
}

* BRAZIL
if `i'==3 {
local pais="bra"
gen isco_2d_c63 = 0
}

* CHILE
if `i'==4 {
local pais="chl"
* No changes
}

* COLOMBIA
if `i'==5 {
local pais="col"
* No changes
}

* COSTA RICA
if `i'==6 {
local pais="cri"
gen isco_2d_c63 = 0
}

* DOMINICAN REPUBLIC
if `i'==7 {
local pais="dom"
gen isco_2d_c63 = 0
}

* ECUADOR
if `i'==8 {
local pais="ecu"
* No changes
}

* GUATEMALA
if `i'==9 {
local pais="gtm"
gen isco_2d_c82 = 0
}

* HONDURAS
if `i'==10 {
local pais="hnd"
gen isco_2d_c63 = 0
}

* MEXICO
if `i'==11 {
local pais="mex"
* No changes
}

* NICARAGUA
if `i'==12 {
local pais="nic"
gen isco_2d_c94 = 0
}

* PANAMA
if `i'==13 {
local pais="pan"
* No changes
}

* PERU
if `i'==14 {
local pais="per"
* No changes
}

* EL SALVADOR
if `i'==15 {
local pais="slv"
* No changes
}

* URUGUAY
if `i'==16 {
local pais="ury"
gen isco_2d_c63 = 0
}



** Predict
summ isco_2d_c11 isco_2d_c12 isco_2d_c13 isco_2d_c14 isco_2d_c21 isco_2d_c22 isco_2d_c23 isco_2d_c24 /// 
isco_2d_c25 isco_2d_c26 isco_2d_c31 isco_2d_c32 isco_2d_c33 isco_2d_c34 isco_2d_c35 ///
isco_2d_c41 isco_2d_c42 isco_2d_c43 isco_2d_c44 isco_2d_c51 isco_2d_c52 isco_2d_c53 ///
isco_2d_c54 isco_2d_c61 isco_2d_c62 isco_2d_c63 isco_2d_c71 isco_2d_c72 isco_2d_c73 ///
isco_2d_c74 isco_2d_c75 isco_2d_c81 isco_2d_c82 isco_2d_c83 isco_2d_c91 isco_2d_c92 ///
isco_2d_c93 isco_2d_c94 isco_2d_c95 isco_2d_c96 ageg10lfs_d2-ageg10lfs_d5 female ///
high_educ log_gdp internet_users_rate broadband_rate

order pais ano isco_2d_c11 isco_2d_c12 isco_2d_c13 isco_2d_c14 isco_2d_c21 isco_2d_c22 isco_2d_c23 isco_2d_c24 /// 
isco_2d_c25 isco_2d_c26 isco_2d_c31 isco_2d_c32 isco_2d_c33 isco_2d_c34 isco_2d_c35 ///
isco_2d_c41 isco_2d_c42 isco_2d_c43 isco_2d_c44 isco_2d_c51 isco_2d_c52 isco_2d_c53 ///
isco_2d_c54 isco_2d_c61 isco_2d_c62 isco_2d_c63 isco_2d_c71 isco_2d_c72 isco_2d_c73 ///
isco_2d_c74 isco_2d_c75 isco_2d_c81 isco_2d_c82 isco_2d_c83 isco_2d_c91 isco_2d_c92 ///
isco_2d_c93 isco_2d_c94 isco_2d_c95 isco_2d_c96 ageg10lfs_d2-ageg10lfs_d5 female ///
high_educ log_gdp internet_users_rate broadband_rate


local controls = "isco_2d_c12 isco_2d_c13 isco_2d_c14 isco_2d_c21 isco_2d_c22 isco_2d_c23 isco_2d_c24 isco_2d_c25 isco_2d_c26 isco_2d_c31 isco_2d_c32 isco_2d_c33 isco_2d_c34 isco_2d_c35 isco_2d_c41 isco_2d_c42 isco_2d_c43 isco_2d_c44 isco_2d_c51 isco_2d_c52 isco_2d_c53 isco_2d_c54 isco_2d_c61 isco_2d_c62 isco_2d_c63 isco_2d_c71 isco_2d_c72 isco_2d_c73 isco_2d_c74 isco_2d_c75 isco_2d_c81 isco_2d_c82 isco_2d_c83 isco_2d_c91 isco_2d_c92 isco_2d_c93 isco_2d_c94 isco_2d_c95 isco_2d_c96 ageg10lfs_d2 ageg10lfs_d3 ageg10lfs_d4 ageg10lfs_d5 female high_educ log_gdp internet_users_rate broadband_rate"

foreach c of local controls {
rename `c' v_`c'
}

* Computer at work SEDLAC
svmat coef_logit, names(col)
foreach c of local controls {
local coef_`c'=`c'[_n==1]
drop `c'
}

gen xb = `cte'
foreach c of local controls {
replace xb=xb+(v_`c' * `coef_`c'')
}

gen computer_work_sedlac = exp(xb)/(1+exp(xb))
summ computer_work_sedlac [w=pondera]


* Computer and internet at work SEDLAC
svmat coef_logit_int, names(col)
foreach c of local controls {
local coef_int_`c'=`c'[_n==1]
drop `c'
}

gen xb_int = `cte_int'
foreach c of local controls {
replace xb_int=xb_int+(v_`c' * `coef_int_`c'')
}

gen internet_work_sedlac = exp(xb_int)/(1+exp(xb_int))
summ internet_work_sedlac [w=pondera]



tempfile piaac_`pais'
sort id com 
save `piaac_`pais'', replace


}




************************* MERGE AI EXPOSURE WITH COMPUTER & INTERNET AT WORK (PIAAC)*************************
*** Countries with ISCO 4d information
local base_in_1   "$path\bases\sedlac\CHL\CHL_2022_CASEN_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_2   "$path\bases\sedlac\DOM\DOM_2021_ECNFT_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_3   "$path\bases\sedlac\ECU\ECU_2021_ENEMDU_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_4   "$path\bases\sedlac\HND\HND_2019_EPHPM_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_5   "$path\bases\sedlac\PAN\PAN_2018_EH_v01_M_v05_A_SEDLAC-03_all.dta"
local base_in_6   "$path\bases\sedlac\PER\PER_2021_ENAHO_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_7   "$path\bases\sedlac\SLV\SLV_2021_EHPM_v01_M_v01_A_SEDLAC-03_all.dta"
local base_in_8   "$path\bases\sedlac\URY\URY_2021_ECH-S2_v01_M_v01_A_SEDLAC-03_all.dta"



* Number of countries with ISCO 4d information
local t = 8


forvalue i = 1/`t'	{

use "`base_in_`i''", clear
di in ye "Base = `base_in_`i''"

replace pais=lower(pais)

* Chile 2022 (4d)
if `i'==1 {
local pais = "chl"

replace isco08_4d = "." if  isco08_4d == "0-66"
replace isco08_4d = "." if  isco08_4d == "0-88"
replace isco08_4d = "." if  isco08_4d == "0-99"

destring isco08_4d, replace 

* Calculos a 2 dígitos
replace isco08_2d="" if isco08_2d=="0-"
destring isco08_2d, replace
summ isco* 
}


* República Dominicana 2021 (4d)
if `i'==2 {
local pais = "dom"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Ecuador 2021 (4d)
if `i'==3 {
local pais = "ecu"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Honduras 2019 (4d)
if `i'==4 {
local pais = "hnd"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Panama 2018 (4d)
if `i'==5 {
local pais = "pan"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 

* Replace variable "sector"
replace sector = 2 if sector==3
}


* Peru 2021 (4d)
if `i'==6 {
local pais = "per"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* El Salvador 2021 (4d)
if `i'==7 {
local pais = "slv"

destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}


* Uruguay 2021 (4d)
if `i'==8 {
local pais = "ury"

replace isco08_4d = "." if  isco08_4d == "0"
destring isco08_4d, replace 

* Calculos a 2 dígitos
destring isco08_2d, replace
summ isco* 
}



* Imputation of ILO AI exposure scores
sort isco08_4d
merge isco08_4d using "$path\bases\Processed\ILO_db.dta", force
ta _merge
keep if _merge==1 | _merge==3
drop _merge


* Merge to get computer_work_sedlac variable
sort id com 
merge id com using `piaac_`pais'', keep(computer_work_sedlac internet_work_sedlac)
ta _merge
keep if _merge==1 | _merge==3
drop _merge

ta potential, g(pot)
rename pot1 pot_augmen
rename pot2 pot_automa
rename pot3 pot_unknown
rename pot4 pot_missing

gen ncomputer_work_sedlac=1-computer_work_sedlac
gen ninternet_work_sedlac=1-internet_work_sedlac

** Generate variables to estimate probabilities
/* Computer and internet at work
Pr(Augmentation=1, Computer at work=1)
Pr(Augmentation=1, Computer at work=0)
Pr(Automation=1, Computer at work=1)
Pr(Automation=1, Computer at work=0)
Pr(Big Unknown=1, Computer at work=1)
Pr(Big Unknown=1, Computer at work=0)
Pr(Missing=1, Computer at work=1)
Pr(Missing=1, Computer at work=0)
*/
gen augmen_compu=pot_augmen*computer_work_sedlac
gen augmen_ncompu=pot_augmen*ncomputer_work_sedlac
gen automa_compu=pot_automa*computer_work_sedlac
gen automa_ncompu=pot_automa*ncomputer_work_sedlac
gen unknown_compu=pot_unknown*computer_work_sedlac
gen unknown_ncompu=pot_unknown*ncomputer_work_sedlac
gen missing_compu=pot_missing*computer_work_sedlac
gen missing_ncompu=pot_missing*ncomputer_work_sedlac


/* Computer and internet at work
Pr(Augmentation=1, Computer & internet at work=1)
Pr(Augmentation=1, Computer & internet at work=0)
Pr(Automation=1, Computer & internet at work=1)
Pr(Automation=1, Computer & internet at work=0)
Pr(Big Unknown=1, Computer & internet at work=1)
Pr(Big Unknown=1, Computer & internet at work=0)
Pr(Missing=1, Computer & internet at work=1)
Pr(Missing=1, Computer & internet at work=0)
*/
gen augmen_int=pot_augmen*internet_work_sedlac
gen augmen_nint=pot_augmen*ninternet_work_sedlac
gen automa_int=pot_automa*internet_work_sedlac
gen automa_nint=pot_automa*ninternet_work_sedlac
gen unknown_int=pot_unknown*internet_work_sedlac
gen unknown_nint=pot_unknown*ninternet_work_sedlac
gen missing_int=pot_missing*internet_work_sedlac
gen missing_nint=pot_missing*ninternet_work_sedlac



*** GENERATE VARIABLES FOR PROFILE 
* Variable g_edad
gen g_edad = 1 if edad>=15 & edad<=24 
replace g_edad = 2 if edad>=25 & edad<=34
replace g_edad = 3 if edad>=35 & edad<=44
replace g_edad = 4 if edad>=45 & edad<=54
replace g_edad = 5 if edad>=55 & edad<=64

* Variable pobre685
sort pais ano
merge pais ano using "$path\bases\Processed\ipc_sedlac_wb.dta", force keep(ppp17 ipc_sedlac ipc17_sedlac conversion)
ta _merge
keep if _merge==3
drop _merge

gen lp_685usd = (6.85*365/12)*ppp17*(ipc_sedlac/ipc17_sedlac)*conversion

gen pobre685 = 0 if ipcf!=.
replace pobre685 = 1 if ipcf<lp_685usd

* Variable qipcf
cuantiles ipcf [w=pondera] if ipcf>=0 & cohh==1, n(5) orden_aux(id com relacion edad) g(qipcf)

* Variable informal_1
gen     informal_1 = 0 if categ_lab==1
replace informal_1 = 1 if categ_lab==2

* Variable informal_2
gen     informal_2 = 1-djubila
replace informal_2 = . if asal!=1




*** PROFILE FOR AI & COMPUTER AT WORK
local potential = "augmen_compu augmen_ncompu automa_compu automa_ncompu unknown_compu unknown_ncompu missing_compu missing_ncompu"
*mat `pais'_ai_comp = J(8,28,.)
mat `pais'_ai_comp = J(8,38,.)

local cat = 1
foreach pot of local potential {

* TOTAL
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat `pais'_ai_comp[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h'
mat `pais'_ai_comp[`cat',2+`h']= r(mean)*100
}


* AREA (URBANO)
forvalues u =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u'
mat `pais'_ai_comp[`cat',4+`u']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a'
mat `pais'_ai_comp[`cat',5+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e'
mat `pais'_ai_comp[`cat',10+`e']= r(mean)*100
}


* POVERTY
forvalues p =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p'
mat `pais'_ai_comp[`cat',14+`p']= r(mean)*100
}


* QUINTIL (IPCF)
forvalues q =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q'
mat `pais'_ai_comp[`cat',15+`q']= r(mean)*100
}


* LEGAL INFORMALITY (DJUBILA)
forvalues f =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f'
mat `pais'_ai_comp[`cat',21+`f']= r(mean)*100
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
forvalues c =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c'
mat `pais'_ai_comp[`cat',23+`c']= r(mean)*100
}

* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r'
mat `pais'_ai_comp[`cat',24+`r']= r(mean)*100
}

* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'
mat `pais'_ai_comp[`cat',28+`s']= r(mean)*100
}


local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}


*** PROFILE FOR AI & COMPUTER AND INTERNET AT WORK
local potential = "augmen_int augmen_nint automa_int automa_nint unknown_int unknown_nint missing_int missing_nint"
mat `pais'_ai_int = J(8,38,.)

local cat = 1
foreach pot of local potential {

* TOTAL
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat `pais'_ai_int[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h'
mat `pais'_ai_int[`cat',2+`h']= r(mean)*100
}


* AREA (URBANO)
forvalues u =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u'
mat `pais'_ai_int[`cat',4+`u']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a'
mat `pais'_ai_int[`cat',5+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e'
mat `pais'_ai_int[`cat',10+`e']= r(mean)*100
}


* POVERTY
forvalues p =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p'
mat `pais'_ai_int[`cat',14+`p']= r(mean)*100
}


* QUINTIL (IPCF)
forvalues q =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q'
mat `pais'_ai_int[`cat',15+`q']= r(mean)*100
}


* LEGAL INFORMALITY (DJUBILA)
forvalues f =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f'
mat `pais'_ai_int[`cat',21+`f']= r(mean)*100
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
forvalues c =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c'
mat `pais'_ai_int[`cat',23+`c']= r(mean)*100
}

* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r'
mat `pais'_ai_int[`cat',24+`r']= r(mean)*100
}

* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'
mat `pais'_ai_int[`cat',28+`s']= r(mean)*100
}


local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}



** CLOSE COUNTRY
}
mat dir



clear

*** Countries with ISCO 2d information, and matched with SEDLAC database of countries with ISCO 4d information
local base_in_1   "$path\bases\sedlac\ARG\ARG_2021_EPHC-S2_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_2   "$path\bases\sedlac\BOL\BOL_2021_EH_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_3   "$path\bases\sedlac\GTM\GTM_2014_ENCOVI_v02_M_v02_A_SEDLAC-03_all_ocupa.dta"
local base_in_4   "$path\bases\sedlac\NIC\NIC_2014_EMNV_v02_M_v02_A_SEDLAC-03_all.dta"


* Number of countries with ISCO 2d information
local t = 4

forvalue i = 1/`t'	{

use "`base_in_`i''", clear
di in ye "Base = `base_in_`i''"


* Argentina 2021 (2d)
if `i'==1 {
local pais = "arg"
local match = "ury"

destring isco08_2d, replace
}

* Bolivia 2021 (2d)
if `i'==2 {
local pais = "bol"
local match = "slv"

destring isco08_2d, replace
}

* Guatemala 2014 (2d)
if `i'==3 {
replace pais=lower(pais)

local pais = "gtm"
local match = "hnd"

destring isco08_2d, replace
}

* Nicaragua 2014 (2d)
if `i'==4 {
local pais = "nic"
local match = "hnd"

destring isco08_2d, replace
}


*** GENERATE VARIABLES FOR PROFILE 
* Variable g_edad
gen g_edad = 1 if edad>=15 & edad<=24 
replace g_edad = 2 if edad>=25 & edad<=34
replace g_edad = 3 if edad>=35 & edad<=44
replace g_edad = 4 if edad>=45 & edad<=54
replace g_edad = 5 if edad>=55 & edad<=64

* Variable pobre685
sort pais ano
merge pais ano using "$path\bases\Processed\ipc_sedlac_wb.dta", force keep(ppp17 ipc_sedlac ipc17_sedlac conversion)
ta _merge
keep if _merge==3
drop _merge

gen lp_685usd = (6.85*365/12)*ppp17*(ipc_sedlac/ipc17_sedlac)*conversion

gen pobre685 = 0 if ipcf!=.
replace pobre685 = 1 if ipcf<lp_685usd

* Variable qipcf
cuantiles ipcf [w=pondera] if ipcf>=0 & cohh==1, n(5) orden_aux(id com relacion edad) g(qipcf)

* Variable informal_1
gen     informal_1 = 0 if categ_lab==1
replace informal_1 = 1 if categ_lab==2

* Variable informal_2
gen     informal_2 = 1-djubila
replace informal_2 = . if asal!=1


** Merge to get potential (AI)
* Match with "`match'"
sort isco08_2d hombre 
ta pais
merge isco08_2d hombre using "$path\bases\Processed\matchISCO_`match'_SEDLAC.dta", force
ta _merge
keep if _merge==1 | _merge==3
drop _merge


* Merge to get computer_work_sedlac variable
sort id com 
merge id com using `piaac_`pais'', keep(computer_work_sedlac internet_work_sedlac)
ta _merge
keep if _merge==1 | _merge==3
drop _merge

gen ncomputer_work_sedlac=1-computer_work_sedlac
gen ninternet_work_sedlac=1-internet_work_sedlac


** Generate variables to estimate probabilities
/* AI and Computer at work
Pr(Augmentation=1, Computer at work=1)
Pr(Augmentation=1, Computer at work=0)
Pr(Automation=1, Computer at work=1)
Pr(Automation=1, Computer at work=0)
Pr(Big Unknown=1, Computer at work=1)
Pr(Big Unknown=1, Computer at work=0)
Pr(Missing=1, Computer at work=1)
Pr(Missing=1, Computer at work=0)
*/
gen augmen_compu=exp_augmen_2d*computer_work_sedlac
gen augmen_ncompu=exp_augmen_2d*ncomputer_work_sedlac
gen automa_compu=exp_automa_2d*computer_work_sedlac
gen automa_ncompu=exp_automa_2d*ncomputer_work_sedlac
gen unknown_compu=exp_unknown_2d*computer_work_sedlac
gen unknown_ncompu=exp_unknown_2d*ncomputer_work_sedlac
gen missing_compu=exp_missing_2d*computer_work_sedlac
gen missing_ncompu=exp_missing_2d*ncomputer_work_sedlac

/* AI and Computer & Internet at work
Pr(Augmentation=1, Computer and Internet at work=1)
Pr(Augmentation=1, Computer and Internet at work=0)
Pr(Automation=1, Computer and Internet at work=1)
Pr(Automation=1, Computer and Internet at work=0)
Pr(Big Unknown=1, Computer and Internet at work=1)
Pr(Big Unknown=1, Computer and Internet at work=0)
Pr(Missing=1, Computer and Internet at work=1)
Pr(Missing=1, Computer and Internet at work=0)
*/
gen augmen_int=exp_augmen_2d*internet_work_sedlac
gen augmen_nint=exp_augmen_2d*ninternet_work_sedlac
gen automa_int=exp_automa_2d*internet_work_sedlac
gen automa_nint=exp_automa_2d*ninternet_work_sedlac
gen unknown_int=exp_unknown_2d*internet_work_sedlac
gen unknown_nint=exp_unknown_2d*ninternet_work_sedlac
gen missing_int=exp_missing_2d*internet_work_sedlac
gen missing_nint=exp_missing_2d*ninternet_work_sedlac





*** PROFILE 
local potential = "augmen_compu augmen_ncompu automa_compu automa_ncompu unknown_compu unknown_ncompu missing_compu missing_ncompu"
*mat `pais'_ai_comp = J(8,28,.)
mat `pais'_ai_comp = J(8,38,.)

local cat = 1
foreach pot of local potential {

* TOTAL
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat `pais'_ai_comp[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h'
mat `pais'_ai_comp[`cat',2+`h']= r(mean)*100
}


* AREA (URBANO)
forvalues u =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u'
mat `pais'_ai_comp[`cat',4+`u']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a'
mat `pais'_ai_comp[`cat',5+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e'
mat `pais'_ai_comp[`cat',10+`e']= r(mean)*100
}


* POVERTY
forvalues p =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p'
mat `pais'_ai_comp[`cat',14+`p']= r(mean)*100
}


* QUINTIL (IPCF)
forvalues q =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q'
mat `pais'_ai_comp[`cat',15+`q']= r(mean)*100
}


* LEGAL INFORMALITY (DJUBILA)
forvalues f =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f'
mat `pais'_ai_comp[`cat',21+`f']= r(mean)*100
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
forvalues c =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c'
mat `pais'_ai_comp[`cat',23+`c']= r(mean)*100
}

* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r'
mat `pais'_ai_comp[`cat',24+`r']= r(mean)*100
}

* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'
mat `pais'_ai_comp[`cat',28+`s']= r(mean)*100
}

local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}



*** PROFILE FOR AI & COMPUTER AND INTERNET AT WORK
local potential = "augmen_int augmen_nint automa_int automa_nint unknown_int unknown_nint missing_int missing_nint"
mat `pais'_ai_int = J(8,38,.)

local cat = 1
foreach pot of local potential {

* TOTAL
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat `pais'_ai_int[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h'
mat `pais'_ai_int[`cat',2+`h']= r(mean)*100
}


* AREA (URBANO)
forvalues u =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u'
mat `pais'_ai_int[`cat',4+`u']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a'
mat `pais'_ai_int[`cat',5+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e'
mat `pais'_ai_int[`cat',10+`e']= r(mean)*100
}


* POVERTY
forvalues p =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p'
mat `pais'_ai_int[`cat',14+`p']= r(mean)*100
}


* QUINTIL (IPCF)
forvalues q =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q'
mat `pais'_ai_int[`cat',15+`q']= r(mean)*100
}


* LEGAL INFORMALITY (DJUBILA)
forvalues f =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f'
mat `pais'_ai_int[`cat',21+`f']= r(mean)*100
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
forvalues c =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c'
mat `pais'_ai_int[`cat',23+`c']= r(mean)*100
}

* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r'
mat `pais'_ai_int[`cat',24+`r']= r(mean)*100
}

* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'
mat `pais'_ai_int[`cat',28+`s']= r(mean)*100
}


local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}



** CLOSE COUNTRY
}
mat dir



clear

*** Countries with ISCO 2d information, and matched with ILO & WB database
local base_in_1   "$path\bases\sedlac\BRA\BRA_2021_PNADC-E5_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_2   "$path\bases\sedlac\COL\COL_2019_GEIH_v01_M_v02_A_SEDLAC-03_all.dta"
local base_in_3   "$path\bases\sedlac\CRI\CRI_2019_ENAHO_v02_M_v02_A_SEDLAC-03_all.dta"
local base_in_4   "$path\bases\sedlac\MEX\MEX_2018_ENIGHNS_v02_M_v02_A_SEDLAC-03_all.dta"


* Number of countries with ISCO 2d information
local t = 4

forvalue i = 1/`t'	{

use "`base_in_`i''", clear
di in ye "Base = `base_in_`i''"


* Brazil 2021 (2d)
if `i'==1 {
local pais = "bra"

destring isco08_2d, replace
}

* Colombia 2019 (2d)
if `i'==2 {
local pais = "col"

destring isco08_2d, replace
}

* Costa Rica 2019 (2d)
if `i'==3 {
local pais = "cri"

destring isco08_2d, replace
}

* Mexico 2018 (2d)
if `i'==4 {
local pais = "mex"

destring isco08_2d, replace
}

*** GENERATE VARIABLES FOR PROFILE 
* Variable g_edad
gen g_edad = 1 if edad>=15 & edad<=24 
replace g_edad = 2 if edad>=25 & edad<=34
replace g_edad = 3 if edad>=35 & edad<=44
replace g_edad = 4 if edad>=45 & edad<=54
replace g_edad = 5 if edad>=55 & edad<=64

* Variable pobre685
sort pais ano
merge pais ano using "$path\bases\Processed\ipc_sedlac_wb.dta", force keep(ppp17 ipc_sedlac ipc17_sedlac conversion)
ta _merge
keep if _merge==3
drop _merge

gen lp_685usd = (6.85*365/12)*ppp17*(ipc_sedlac/ipc17_sedlac)*conversion

gen pobre685 = 0 if ipcf!=.
replace pobre685 = 1 if ipcf<lp_685usd

* Variable qipcf
cuantiles ipcf [w=pondera] if ipcf>=0 & cohh==1, n(5) orden_aux(id com relacion edad) g(qipcf)

* Variable informal_1
gen     informal_1 = 0 if categ_lab==1
replace informal_1 = 1 if categ_lab==2

* Variable informal_2
gen     informal_2 = 1-djubila
replace informal_2 = . if asal!=1


* Pequeña modificación dado que para calcular los shares en la base de ILO WB se contempla a los ocupados con missing en ISCO 
replace isco08_2d=999 if ocupado==1 & isco08_2d==. 



* Match with data from the same country using ILO & WB database
ta pais
sort pais isco08_2d hombre
merge pais isco08_2d hombre using "$path\bases\Processed\matchISCO_ILOWB.dta", force
ta _merge
keep if _merge==1 | _merge==3
drop _merge


replace exp_augmen_2d = 0 if exp_augmen_2d==.
replace exp_automa_2d = 0 if exp_automa_2d==.
replace exp_unknown_2d = 0 if exp_unknown_2d==.
gen exp_missing_2d = 1-exp_augmen_2d-exp_automa_2d-exp_unknown_2d


* Merge to get computer_work_sedlac variable
sort id com 
merge id com using `piaac_`pais'', keep(computer_work_sedlac internet_work_sedlac)
ta _merge
keep if _merge==1 | _merge==3
drop _merge

gen ncomputer_work_sedlac=1-computer_work_sedlac
gen ninternet_work_sedlac=1-internet_work_sedlac

** Generate variables to estimate probabilities
/* AI and Computer at work
Pr(Augmentation=1, Computer at work=1)
Pr(Augmentation=1, Computer at work=0)
Pr(Automation=1, Computer at work=1)
Pr(Automation=1, Computer at work=0)
Pr(Big Unknown=1, Computer at work=1)
Pr(Big Unknown=1, Computer at work=0)
Pr(Missing=1, Computer at work=1)
Pr(Missing=1, Computer at work=0)
*/
gen augmen_compu=exp_augmen_2d*computer_work_sedlac
gen augmen_ncompu=exp_augmen_2d*ncomputer_work_sedlac
gen automa_compu=exp_automa_2d*computer_work_sedlac
gen automa_ncompu=exp_automa_2d*ncomputer_work_sedlac
gen unknown_compu=exp_unknown_2d*computer_work_sedlac
gen unknown_ncompu=exp_unknown_2d*ncomputer_work_sedlac
gen missing_compu=exp_missing_2d*computer_work_sedlac
gen missing_ncompu=exp_missing_2d*ncomputer_work_sedlac

/* AI and Computer & Internet at work
Pr(Augmentation=1, Computer and Internet at work=1)
Pr(Augmentation=1, Computer and Internet at work=0)
Pr(Automation=1, Computer and Internet at work=1)
Pr(Automation=1, Computer and Internet at work=0)
Pr(Big Unknown=1, Computer and Internet at work=1)
Pr(Big Unknown=1, Computer and Internet at work=0)
Pr(Missing=1, Computer and Internet at work=1)
Pr(Missing=1, Computer and Internet at work=0)
*/
gen augmen_int=exp_augmen_2d*internet_work_sedlac
gen augmen_nint=exp_augmen_2d*ninternet_work_sedlac
gen automa_int=exp_automa_2d*internet_work_sedlac
gen automa_nint=exp_automa_2d*ninternet_work_sedlac
gen unknown_int=exp_unknown_2d*internet_work_sedlac
gen unknown_nint=exp_unknown_2d*ninternet_work_sedlac
gen missing_int=exp_missing_2d*internet_work_sedlac
gen missing_nint=exp_missing_2d*ninternet_work_sedlac


*** PROFILE 
local potential = "augmen_compu augmen_ncompu automa_compu automa_ncompu unknown_compu unknown_ncompu missing_compu missing_ncompu"
*mat `pais'_ai_comp = J(8,28,.)
mat `pais'_ai_comp = J(8,38,.)

local cat = 1
foreach pot of local potential {

* TOTAL
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat `pais'_ai_comp[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h'
mat `pais'_ai_comp[`cat',2+`h']= r(mean)*100
}


* AREA (URBANO)
forvalues u =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u'
mat `pais'_ai_comp[`cat',4+`u']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a'
mat `pais'_ai_comp[`cat',5+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e'
mat `pais'_ai_comp[`cat',10+`e']= r(mean)*100
}


* POVERTY
forvalues p =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p'
mat `pais'_ai_comp[`cat',14+`p']= r(mean)*100
}


* QUINTIL (IPCF)
forvalues q =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q'
mat `pais'_ai_comp[`cat',15+`q']= r(mean)*100
}


* LEGAL INFORMALITY (DJUBILA)
forvalues f =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f'
mat `pais'_ai_comp[`cat',21+`f']= r(mean)*100
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
forvalues c =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c'
mat `pais'_ai_comp[`cat',23+`c']= r(mean)*100
}

* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r'
mat `pais'_ai_comp[`cat',24+`r']= r(mean)*100
}

* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'
mat `pais'_ai_comp[`cat',28+`s']= r(mean)*100
}


local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}


*** PROFILE FOR AI & COMPUTER AND INTERNET AT WORK
local potential = "augmen_int augmen_nint automa_int automa_nint unknown_int unknown_nint missing_int missing_nint"
mat `pais'_ai_int = J(8,38,.)

local cat = 1
foreach pot of local potential {

* TOTAL
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1
mat `pais'_ai_int[`cat',1]= r(mean)*100


* GENDER (HOMBRE)
forvalues h =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & hombre==`h'
mat `pais'_ai_int[`cat',2+`h']= r(mean)*100
}


* AREA (URBANO)
forvalues u =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & urbano==`u'
mat `pais'_ai_int[`cat',4+`u']= r(mean)*100
}


* AGE (G_EDAD)
forvalues a =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & g_edad==`a'
mat `pais'_ai_int[`cat',5+`a']= r(mean)*100
}


* EDUCATION (NIVEDU)
forvalues e =1(1)3 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & nivedu==`e'
mat `pais'_ai_int[`cat',10+`e']= r(mean)*100
}


* POVERTY
forvalues p =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & pobre685==`p'
mat `pais'_ai_int[`cat',14+`p']= r(mean)*100
}


* QUINTIL (IPCF)
forvalues q =1(1)5 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & qipcf==`q'
mat `pais'_ai_int[`cat',15+`q']= r(mean)*100
}


* LEGAL INFORMALITY (DJUBILA)
forvalues f =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_2==`f'
mat `pais'_ai_int[`cat',21+`f']= r(mean)*100
}


* PRODUCTIVE INFORMALITY (CATEG_LAB)
forvalues c =0(1)1 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & informal_1==`c'
mat `pais'_ai_int[`cat',23+`c']= r(mean)*100
}

* LABOR RELATIONSHIP (RELAB)
forvalues r =1(1)4 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & relab==`r'
mat `pais'_ai_int[`cat',24+`r']= r(mean)*100
}

* ECONOMIC ACTIVITY SECTOR (SECTOR)
forvalues s =1(1)10 {
summ `pot' [w=pondera] if ocupado==1 & edad>=15 & edad<=64 & cohh==1 & sector==`s'
mat `pais'_ai_int[`cat',28+`s']= r(mean)*100
}


local cat = `cat'+1
** CLOSE PROFILES FOR EACH AI CATEGORY 
}



** CLOSE COUNTRY
}
mat dir















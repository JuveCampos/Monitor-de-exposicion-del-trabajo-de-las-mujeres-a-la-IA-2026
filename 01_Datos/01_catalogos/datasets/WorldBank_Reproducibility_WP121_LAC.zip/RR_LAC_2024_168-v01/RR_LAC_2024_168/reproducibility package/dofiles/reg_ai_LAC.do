*** Regression - pool of LAC countries (16)

use "$path\bases\Processed\AI_regress_LAC.dta", clear

* Normalize weights by country_code
egen aux=sum(pondera), by(pais)
gen weight_sedlac_relative=pondera*100/aux
drop aux

encode pais, g(npais)
tab npais, g(pais_) 

tab ano, g(year)

mat mean_dep = J(1,3,.)

** With Weights (relative)
* Augmentation
regress ai_augmen female urbano ageg10lfs_d2 ageg10lfs_d3 ageg10lfs_d4 ageg10lfs_d5 edu_2 edu_3 q_2 q_3 q_4 q_5 informal_2 relab_1 relab_2 relab_3 s_2-s_10 pais_2-pais_9 pais_11 pais_14-pais_16 year2-year4 [pw=weight_sedlac_relative]
outreg2 using "$path_xls\regress_pool.xls", replace
summ ai_augmen [w=weight_sedlac_relative] if e(sample)
mat mean_dep[1,1]=r(mean)

* Automation
regress ai_automa female urbano ageg10lfs_d2 ageg10lfs_d3 ageg10lfs_d4 ageg10lfs_d5 edu_2 edu_3 q_2 q_3 q_4 q_5 informal_2 relab_1 relab_2 relab_3 s_2-s_10 pais_2-pais_9 pais_11 pais_14-pais_16 year2-year4 [pw=weight_sedlac_relative]
outreg2 using "$path_xls\regress_pool.xls", append
summ ai_automa [w=weight_sedlac_relative] if e(sample)
mat mean_dep[1,2]=r(mean)

* The big unknown
regress ai_unknown female urbano ageg10lfs_d2 ageg10lfs_d3 ageg10lfs_d4 ageg10lfs_d5 edu_2 edu_3 q_2 q_3 q_4 q_5 informal_2 relab_1 relab_2 relab_3 s_2-s_10 pais_2-pais_9 pais_11 pais_14-pais_16 year2-year4 [pw=weight_sedlac_relative]
outreg2 using "$path_xls\regress_pool.xls", append
summ ai_unknown [w=weight_sedlac_relative] if e(sample)
mat mean_dep[1,3]=r(mean)

********* TRANSFERENCIA A XLS *********
drop _all
svmat double mean_dep
outsheet using "$path_xls\meandep.xls", replace

********* CIERRA *********
mat drop _all
clear



********** MATRIZ DE DATA ******** 
mat CPUHH = arg_ai_CPUHH \ bol_ai_CPUHH \ bra_ai_CPUHH \ chl_ai_CPUHH \ col_ai_CPUHH \ cri_ai_CPUHH \ dom_ai_CPUHH \ ecu_ai_CPUHH \ gtm_ai_CPUHH \ hnd_ai_CPUHH \ mex_ai_CPUHH \ nic_ai_CPUHH \ pan_ai_CPUHH \ per_ai_CPUHH \ slv_ai_CPUHH \ ury_ai_CPUHH
*mat INTHH = arg_ai_INTHH \ bol_ai_INTHH \ bra_ai_INTHH \ chl_ai_INTHH \ col_ai_INTHH \ cri_ai_INTHH \ dom_ai_INTHH \ ecu_ai_INTHH \ gtm_ai_INTHH \ hnd_ai_INTHH \ mex_ai_INTHH \ nic_ai_INTHH \ pan_ai_INTHH \ per_ai_INTHH \ slv_ai_INTHH \ ury_ai_INTHH
*mat INTandCPUHH = arg_ai_INTandCPUHH \ bol_ai_INTandCPUHH \ bra_ai_INTandCPUHH \ chl_ai_INTandCPUHH \ col_ai_INTandCPUHH \ cri_ai_INTandCPUHH \ dom_ai_INTandCPUHH \ ecu_ai_INTandCPUHH \ gtm_ai_INTandCPUHH \ hnd_ai_INTandCPUHH \ mex_ai_INTandCPUHH \ nic_ai_INTandCPUHH \ pan_ai_INTandCPUHH \ per_ai_INTandCPUHH \ slv_ai_INTandCPUHH \ ury_ai_INTandCPUHH
*mat INTorCPUHH = arg_ai_INTorCPUHH \ bol_ai_INTorCPUHH \ bra_ai_INTorCPUHH \ chl_ai_INTorCPUHH \ col_ai_INTorCPUHH \ cri_ai_INTorCPUHH \ dom_ai_INTorCPUHH \ ecu_ai_INTorCPUHH \ gtm_ai_INTorCPUHH \ hnd_ai_INTorCPUHH \ mex_ai_INTorCPUHH \ nic_ai_INTorCPUHH \ pan_ai_INTorCPUHH \ per_ai_INTorCPUHH \ slv_ai_INTorCPUHH \ ury_ai_INTorCPUHH

********* TRANSFERENCIA A XLS *********
drop _all
svmat double CPUHH
outsheet using "$path_xls\ai_sedlac_compHH.xls", replace
/*
drop _all
svmat double INTHH
outsheet using "$path_xls\isco_ai_int_all.xls", replace

drop _all
svmat double INTandCPUHH
outsheet using "$path_xls\isco_ai_intandcpu_all.xls", replace
*/
/*
drop _all
svmat double INTorCPUHH
outsheet using "$path_xls\isco_ai_intorcpu_all.xls", replace
*/

********* CIERRA *********
mat drop _all
clear
